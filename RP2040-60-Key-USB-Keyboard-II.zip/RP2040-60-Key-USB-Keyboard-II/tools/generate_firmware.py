#!/usr/bin/env python3
# Copyright 2026 Deonte Lamar Merritt
# SPDX-License-Identifier: MIT
"""Generate the QMK keyboard definition from the hardware specification.

Edit the tables in this file, then run it, when the matrix or the default
keymap changes. The files it writes are what QMK compiles. A one-key change
can also be made directly in keymap.c; keep this file in agreement and rerun
the validator.
"""

from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
KB = ROOT / "firmware" / "qmk" / "keyboards" / "merritt" / "merritt60ii"

# Raspberry Pi Pico header pins. Physical pin numbers match the silkscreen
# on Pico and Pico H (USB connector toward the top of the official drawing).
# GP23, GP24, GP25, and GP29 are not on the user header.
ROWS = [
    ("ROW0", "GP2", 4),
    ("ROW1", "GP3", 5),
    ("ROW2", "GP4", 6),
    ("ROW3", "GP5", 7),
    ("ROW4", "GP6", 9),
]
COLS = [
    ("COL0", "GP7", 10),
    ("COL1", "GP8", 11),
    ("COL2", "GP9", 12),
    ("COL3", "GP10", 14),
    ("COL4", "GP11", 15),
    ("COL5", "GP12", 16),
    ("COL6", "GP13", 17),
    ("COL7", "GP14", 19),
    ("COL8", "GP15", 20),
    ("COL9", "GP16", 21),
    ("COL10", "GP17", 22),
    ("COL11", "GP18", 24),
]

# Each entry is (qmk_keycode, legend printed on the 1u keycap or shown on the Fn chart).
BASE = [
    [("KC_GRV", "`"), ("KC_1", "1"), ("KC_2", "2"), ("KC_3", "3"), ("KC_4", "4"), ("KC_5", "5"), ("KC_6", "6"), ("KC_7", "7"), ("KC_8", "8"), ("KC_9", "9"), ("KC_0", "0"), ("KC_BSPC", "Backspace")],
    [("KC_TAB", "Tab"), ("KC_Q", "Q"), ("KC_W", "W"), ("KC_E", "E"), ("KC_R", "R"), ("KC_T", "T"), ("KC_Y", "Y"), ("KC_U", "U"), ("KC_I", "I"), ("KC_O", "O"), ("KC_P", "P"), ("KC_BSLS", "\\")],
    [("KC_ESC", "Esc"), ("KC_A", "A"), ("KC_S", "S"), ("KC_D", "D"), ("KC_F", "F"), ("KC_G", "G"), ("KC_H", "H"), ("KC_J", "J"), ("KC_K", "K"), ("KC_L", "L"), ("KC_SCLN", ";"), ("KC_QUOT", "'")],
    [("KC_LSFT", "Shift"), ("KC_Z", "Z"), ("KC_X", "X"), ("KC_C", "C"), ("KC_V", "V"), ("KC_B", "B"), ("KC_N", "N"), ("KC_M", "M"), ("KC_COMM", ","), ("KC_DOT", "."), ("KC_SLSH", "/"), ("KC_ENT", "Enter")],
    [("KC_LCTL", "Ctrl"), ("KC_LGUI", "Win"), ("KC_LALT", "Alt"), ("MO(_FN)", "Fn"), ("KC_LBRC", "["), ("KC_RBRC", "]"), ("KC_SPC", "Space"), ("KC_MINS", "-"), ("KC_EQL", "="), ("MO(_FN)", "Fn"), ("KC_DEL", "Del"), ("KC_RSFT", "Shift")],
]
FN = [
    [("QK_BOOT", "Boot"), ("KC_F1", "F1"), ("KC_F2", "F2"), ("KC_F3", "F3"), ("KC_F4", "F4"), ("KC_F5", "F5"), ("KC_F6", "F6"), ("KC_F7", "F7"), ("KC_F8", "F8"), ("KC_F9", "F9"), ("KC_F10", "F10"), ("KC_DEL", "Del")],
    [("KC_F11", "F11"), ("KC_F12", "F12"), ("KC_PSCR", "PrtSc"), ("KC_SCRL", "ScrLk"), ("KC_PAUS", "Pause"), ("_______", "—"), ("KC_HOME", "Home"), ("KC_PGDN", "PgDn"), ("KC_PGUP", "PgUp"), ("KC_END", "End"), ("KC_INS", "Ins"), ("_______", "—")],
    [("_______", "—"), ("_______", "—"), ("_______", "—"), ("_______", "—"), ("_______", "—"), ("_______", "—"), ("KC_LEFT", "Left"), ("KC_DOWN", "Down"), ("KC_UP", "Up"), ("KC_RGHT", "Right"), ("_______", "—"), ("_______", "—")],
    [("_______", "—"), ("_______", "—"), ("_______", "—"), ("_______", "—"), ("_______", "—"), ("_______", "—"), ("_______", "—"), ("_______", "—"), ("KC_MUTE", "Mute"), ("KC_VOLD", "Vol-"), ("KC_VOLU", "Vol+"), ("_______", "—")],
    [("_______", "—"), ("_______", "—"), ("_______", "—"), ("_______", "—"), ("_______", "—"), ("_______", "—"), ("_______", "—"), ("_______", "—"), ("_______", "—"), ("_______", "—"), ("KC_PGUP", "PgUp"), ("KC_PGDN", "PgDn")],
]

SHIFTED = {
    "`": "~", "1": "!", "2": "@", "3": "#", "4": "$", "5": "%", "6": "^",
    "7": "&", "8": "*", "9": "(", "0": ")", "-": "_", "=": "+", "[": "{",
    "]": "}", "\\": "|", ";": ":", "'": '"', ",": "<", ".": ">", "/": "?",
}


def keys():
    items = []
    for r, (base_row, fn_row) in enumerate(zip(BASE, FN)):
        for c, (base, fn) in enumerate(zip(base_row, fn_row)):
            items.append({
                "id": r * 12 + c + 1,
                "row": r,
                "col": c,
                "base_code": base[0],
                "legend": base[1],
                "fn_code": fn[0],
                "fn_legend": fn[1],
                "row_gpio": ROWS[r][1],
                "row_pin": ROWS[r][2],
                "col_gpio": COLS[c][1],
                "col_pin": COLS[c][2],
                "keycap": "1u",
            })
    return items


def design_document():
    return {
        "project": "RP2040 60-Key USB Keyboard II",
        "owner": "Deonte Lamar Merritt",
        "organization": "Merritt Robotics Inc.",
        "controller": {
            "board": "Raspberry Pi Pico",
            "order_code": "SC0915",
            "alternate_assembly_board": "Raspberry Pi Pico H",
            "alternate_order_code": "SC0917",
            "mcu": "RP2040",
            "flash": "Winbond W25Q16JV, 2 MB, on the Pico module",
            "usb": "Built-in micro-USB B receptacle on the Pico",
            "qmk_processor": "RP2040",
            "qmk_bootloader": "rp2040",
            "qmk_board": "GENERIC_RP_RP2040",
            "qmk_version": "0.34.6",
            "qmk_commit": "d9f6dd215f2c4d295c6ad85b1f602125c2d81db1",
        },
        "matrix": {
            "rows": 5,
            "cols": 12,
            "keys": 60,
            "diode": "1N4148",
            "diode_direction": "COL2ROW",
            "cathode": "banded end, connected to the row GPIO",
            "anode": "connected to one switch pin; the other switch pin connects to the column GPIO",
            "scan": "QMK drives one column low at a time and reads the row pins. Internal pull-ups hold rows high. A pressed switch reads as logic 0.",
            "debounce_ms": 5,
            "debounce_type": "sym_defer_g",
            "rows": [
                {"name": name, "gpio": gpio, "pico_pin": pin}
                for name, gpio, pin in ROWS
            ],
            "cols": [
                {"name": name, "gpio": gpio, "pico_pin": pin}
                for name, gpio, pin in COLS
            ],
        },
        "usb": {
            "vid": "0xFEED",
            "pid": "0x4D60",
            "manufacturer": "Merritt Robotics Inc.",
            "product": "RP2040 60-Key USB Keyboard II",
            "device_version": "0.2.0",
            "max_power_ma": 500,
        },
        "keys": keys(),
    }


def keyboard_json():
    layout = []
    for key in keys():
        layout.append({
            "label": key["legend"],
            "matrix": [key["row"], key["col"]],
            "x": key["col"],
            "y": key["row"],
            "w": 1,
            "h": 1,
        })
    return {
        "keyboard_name": "RP2040 60-Key USB Keyboard II",
        "manufacturer": "Merritt Robotics Inc.",
        "maintainer": "Deonte Lamar Merritt",
        "url": "https://qmk.fm",
        "bootloader_instructions": "Hold the BOOTSEL button on the Raspberry Pi Pico while plugging in the micro-USB cable. A drive named RPI-RP2 appears. Copy the UF2 onto that drive.",
        "processor": "RP2040",
        "bootloader": "rp2040",
        "board": "GENERIC_RP_RP2040",
        "diode_direction": "COL2ROW",
        "debounce": 5,
        "build": {
            "debounce_type": "sym_defer_g",
            "firmware_format": "uf2",
        },
        "features": {
            "bootmagic": True,
            "command": False,
            "console": False,
            "extrakey": True,
            "mousekey": False,
            "nkro": True,
        },
        "bootmagic": {"matrix": [0, 0]},
        "host": {"default": {"nkro": True}},
        "usb": {
            "vid": "0xFEED",
            "pid": "0x4D60",
            "device_version": "0.2.0",
            "max_power": 500,
        },
        "tags": ["ortho", "handwired"],
        "matrix_pins": {
            "rows": [gpio for _, gpio, _ in ROWS],
            "cols": [gpio for _, gpio, _ in COLS],
        },
        "layouts": {
            "LAYOUT_ortho_5x12": {
                "c_macro": True,
                "layout": layout,
            }
        },
    }


def keymap_c():
    def row_line(entries):
        return "    " + ", ".join(f"{code:<10}" for code, _ in entries)

    base_rows = ",\n".join(row_line(row) for row in BASE)
    fn_rows = ",\n".join(row_line(row) for row in FN)
    return f"""// Copyright 2026 Deonte Lamar Merritt
// SPDX-License-Identifier: GPL-2.0-or-later
//
// Default keymap for the RP2040 60-Key USB Keyboard II.
// This file is compiled into QMK. QMK sends USB HID keyboard reports.
// Change a key by replacing the keycode below, then rebuild and flash.
// See docs/build-flash-test-guide.md.

#include QMK_KEYBOARD_H

enum layer_names {{
    _BASE = 0,
    _FN,
}};

const uint16_t PROGMEM keymaps[][MATRIX_ROWS][MATRIX_COLS] = {{
    // Physical top row is matrix row 0. Column 0 is the left edge.
    // Hold either Fn key (MO) for the function layer.
    [_BASE] = LAYOUT_ortho_5x12(
{base_rows}
    ),
    // Transparent keys (_______) keep the base key while Fn is held.
    // Fn + top-left key (grave position) is QK_BOOT.
    [_FN] = LAYOUT_ortho_5x12(
{fn_rows}
    ),
}};
"""


def rules_mk():
    return """# Copyright 2026 Deonte Lamar Merritt
# SPDX-License-Identifier: GPL-2.0-or-later
#
# MCU, bootloader, board, matrix, diodes, debounce, and features are set in
# keyboard.json. Leave those settings out of this file so the two cannot disagree.
# QMK 0.34.6 reads keyboard.json and generates the build rules from it.
# The selected ChibiOS board is GENERIC_RP_RP2040 (keyboard.json "board").
# That board does not assume a Pro Micro RP2040 pinout.
"""


def config_h():
    return """// Copyright 2026 Deonte Lamar Merritt
// SPDX-License-Identifier: GPL-2.0-or-later

#pragma once

/*
 * Matrix pins, diode direction, debounce, USB identity, and features live in
 * keyboard.json. Do not redefine them here.
 *
 * The Raspberry Pi Pico stores firmware in a Winbond W25Q16JV. QMK's default
 * W25Q080-compatible second-stage bootloader talks to that chip. Do not define
 * an RP2040_FLASH_* override for this board.
 *
 * Double-tap reset is not enabled. This Pico has a BOOTSEL button and no
 * reset button. Bootloader entry is documented in readme.md.
 */
"""


def keyboard_readme():
    return """# RP2040 60-Key USB Keyboard II

USB HID keyboard for a hand-wired 5×12 matrix on a Raspberry Pi Pico (RP2040).

* Keyboard Maintainer: Deonte Lamar Merritt, Merritt Robotics Inc.
* Hardware Supported: Raspberry Pi Pico (SC0915) or Pico H (SC0917)
* Hardware Availability: Raspberry Pi Pico module plus a hand-wired switch matrix

The `url` field in `keyboard.json` is `https://qmk.fm` because QMK requires a URL and this hand-wired project has no product page. The USB product string is `RP2040 60-Key USB Keyboard II`. The USB manufacturer string is `Merritt Robotics Inc.`

Make example for this keyboard (after setting up your build environment):

    qmk compile -kb merritt/merritt60ii -km default

Flashing example for this keyboard:

    qmk flash -kb merritt/merritt60ii -km default

The build writes `merritt_merritt60ii_default.uf2`. Copy that file to the `RPI-RP2` drive.

See the [QMK build environment setup](https://docs.qmk.fm/newbs_getting_started) and the project guide `docs/build-flash-test-guide.md`.

## Bootloader

Enter the RP2040 UF2 bootloader in either of these ways:

* **BOOTSEL:** unplug the Pico, hold the BOOTSEL button, and plug in the micro-USB cable. Release BOOTSEL when the `RPI-RP2` drive appears. This is the RP2040 ROM bootloader and works even if the application firmware is missing or broken.
* **Bootmagic:** after this firmware has been flashed, unplug the keyboard, hold the top-left key (matrix row 0, column 0, the grave key), and plug the cable back in.
* **Keycode:** hold either Fn key and tap the top-left key. That position is `QK_BOOT` on the Fn layer.

A brand-new Pico with empty flash also appears as `RPI-RP2` the first time it is plugged in.

Double-tap reset is not enabled. The Pico has no reset button.

## License

The keyboard definition in this directory is original work copyright 2026 Deonte Lamar Merritt and is licensed under GPL-2.0-or-later so it can be combined with QMK Firmware. See `COPYING`. It is not MIT-only. QMK Firmware itself remains under its own license.
"""


def keymap_readme():
    return """# Default keymap

`keymap.c` is the file QMK compiles for this keyboard.

* Layer `_BASE` is the typing layer.
* Layer `_FN` is momentary. Hold either key marked Fn.
* `_______` means the base-layer key remains active while Fn is held.
* `QK_BOOT` on Fn + the top-left key reboots into the UF2 bootloader.

To change one key, replace that keycode, then run:

    qmk compile -kb merritt/merritt60ii -km default

Flash the new UF2. The hardware pins do not change when only a keycode changes.
"""


def matrix_table():
    header = (
        "| ID | Row | Col | Legend | Base keycode | Fn action | Fn keycode | "
        "Row GPIO | Pico row pin | Col GPIO | Pico col pin | Keycap |\n"
        "| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |\n"
    )
    lines = [header]
    for key in keys():
        lines.append(
            "| SW{id} / D{id} | {row} | {col} | {legend} | `{base}` | {fn_legend} | `{fn}` | "
            "{row_gpio} | {row_pin} | {col_gpio} | {col_pin} | 1u |\n".format(
                id=key["id"],
                row=key["row"],
                col=key["col"],
                legend=key["legend"].replace("|", "\\|"),
                base=key["base_code"],
                fn_legend=key["fn_legend"].replace("|", "\\|"),
                fn=key["fn_code"],
                row_gpio=key["row_gpio"],
                row_pin=key["row_pin"],
                col_gpio=key["col_gpio"],
                col_pin=key["col_pin"],
                )
        )
    return "".join(lines)


def netlist_csv():
    lines = ["net,pin,description"]
    for key in keys():
        sw = f"SW{key['id']}"
        diode = f"D{key['id']}"
        lines.append(f"COL{key['col']},U1-{key['col_pin']},Pico {key['col_gpio']} column drive")
        lines.append(f"COL{key['col']},{sw}-1,switch terminal toward the column")
        lines.append(f"SW{key['id']}_ANODE,{sw}-2,switch terminal toward the diode anode")
        lines.append(f"SW{key['id']}_ANODE,{diode}-2,1N4148 anode (no band)")
        lines.append(f"ROW{key['row']},{diode}-1,1N4148 cathode (band)")
        lines.append(f"ROW{key['row']},U1-{key['row_pin']},Pico {key['row_gpio']} row sense")
    # unique while preserving order
    seen = set()
    unique = []
    for line in lines:
        if line not in seen:
            seen.add(line)
            unique.append(line)
    return "\n".join(unique) + "\n"


def write_all():
    KB.mkdir(parents=True, exist_ok=True)
    (KB / "keymaps" / "default").mkdir(parents=True, exist_ok=True)
    (ROOT / "hardware").mkdir(parents=True, exist_ok=True)
    (ROOT / "docs").mkdir(parents=True, exist_ok=True)

    design = design_document()
    # The matrix object accidentally used "rows" twice in a draft; the list form
    # below is the one readers and the validator use. Rebuild it cleanly.
    design["matrix"] = {
        "row_count": 5,
        "col_count": 12,
        "key_count": 60,
        "diode": "1N4148 DO-35",
        "diode_direction": "COL2ROW",
        "cathode": "banded end, connected to the row GPIO",
        "anode": "connected to one switch pin; the other switch pin connects to the column GPIO",
        "scan": "QMK drives one column low at a time and reads the row pins with internal pull-ups. A pressed switch reads as logic 0.",
        "debounce_ms": 5,
        "debounce_type": "sym_defer_g",
        "input_pressed_state": 0,
        "rows": [{"name": name, "gpio": gpio, "pico_pin": pin} for name, gpio, pin in ROWS],
        "cols": [{"name": name, "gpio": gpio, "pico_pin": pin} for name, gpio, pin in COLS],
    }

    (ROOT / "hardware" / "design.json").write_text(json.dumps(design, indent=2) + "\n", encoding="utf-8")
    (KB / "keyboard.json").write_text(json.dumps(keyboard_json(), indent=4) + "\n", encoding="utf-8")
    (KB / "keymaps" / "default" / "keymap.c").write_text(keymap_c(), encoding="utf-8")
    (KB / "rules.mk").write_text(rules_mk(), encoding="utf-8")
    (KB / "config.h").write_text(config_h(), encoding="utf-8")
    (KB / "readme.md").write_text(keyboard_readme(), encoding="utf-8")
    (KB / "keymaps" / "default" / "readme.md").write_text(keymap_readme(), encoding="utf-8")
    (ROOT / "hardware" / "netlist.csv").write_text(netlist_csv(), encoding="utf-8")
    (ROOT / "docs" / "_matrix_table.md").write_text(matrix_table(), encoding="utf-8")
    print(f"Wrote keyboard definition under {KB}")


if __name__ == "__main__":
    write_all()
