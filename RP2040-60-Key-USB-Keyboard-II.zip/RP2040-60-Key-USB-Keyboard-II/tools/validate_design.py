#!/usr/bin/env python3
# Copyright 2026 Deonte Lamar Merritt
# SPDX-License-Identifier: MIT
"""Check the keyboard sources against each other.

This does not flash a Pico and does not prove that a physical keyboard works.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
KB = ROOT / "firmware" / "qmk" / "keyboards" / "merritt" / "merritt60ii"

HEADER_GPIO = {f"GP{n}" for n in list(range(0, 23)) + [26, 27, 28]}
NOT_ON_HEADER = {"GP23", "GP24", "GP25", "GP29"}

REQUIRED = [
    ROOT / "README.md",
    ROOT / "LICENSE",
    ROOT / "THIRD_PARTY_NOTICES.md",
    ROOT / ".gitignore",
    ROOT / "docs" / "hardware-specification.md",
    ROOT / "docs" / "bill-of-materials.csv",
    ROOT / "docs" / "wiring-guide.md",
    ROOT / "docs" / "key-layout.md",
    ROOT / "docs" / "build-flash-test-guide.md",
    ROOT / "docs" / "troubleshooting.md",
    ROOT / "docs" / "validation-report.md",
    ROOT / "docs" / "schematic-specification.md",
    KB / "keyboard.json",
    KB / "rules.mk",
    KB / "config.h",
    KB / "readme.md",
    KB / "COPYING",
    KB / "keymaps" / "default" / "keymap.c",
    ROOT / "hardware" / "design.json",
    ROOT / "hardware" / "netlist.csv",
]


def fail(errors: list[str], message: str) -> None:
    errors.append(message)


def keymap_layers(text: str) -> list[list[str]]:
    layers = []
    token = "LAYOUT_ortho_5x12("
    start = 0
    while True:
        at = text.find(token, start)
        if at < 0:
            break
        i = at + len(token)
        depth = 1
        buf = []
        while i < len(text) and depth:
            ch = text[i]
            if ch == "(":
                depth += 1
            elif ch == ")":
                depth -= 1
                if depth == 0:
                    break
            buf.append(ch)
            i += 1
        raw = "".join(buf)
        codes = []
        for part in raw.split(","):
            code = part.strip()
            if code:
                codes.append(code)
        layers.append(codes)
        start = i + 1
    return layers


def matrix_rows_from_layout_doc(text: str) -> list[dict[str, str]]:
    rows = []
    inside = False
    for line in text.splitlines():
        if "<!-- BEGIN MATRIX TABLE -->" in line:
            inside = True
            continue
        if "<!-- END MATRIX TABLE -->" in line:
            break
        if not inside or not line.startswith("| SW"):
            continue
        cells = [cell.strip() for cell in line.strip().strip("|").split("|")]
        rows.append({
            "id": cells[0].split()[0],
            "row": cells[1],
            "col": cells[2],
            "legend": cells[3],
            "base": cells[4].strip("`"),
            "fn": cells[6].strip("`"),
            "row_gpio": cells[7],
            "row_pin": cells[8],
            "col_gpio": cells[9],
            "col_pin": cells[10],
            "keycap": cells[11],
        })
    return rows


def main() -> int:
    errors: list[str] = []
    notes: list[str] = []

    for path in REQUIRED:
        if not path.is_file():
            fail(errors, f"missing file: {path.relative_to(ROOT)}")

    design = json.loads((ROOT / "hardware" / "design.json").read_text(encoding="utf-8"))
    keyboard = json.loads((KB / "keyboard.json").read_text(encoding="utf-8"))
    keymap_text = (KB / "keymaps" / "default" / "keymap.c").read_text(encoding="utf-8")
    layers = keymap_layers(keymap_text)

    keys = design["keys"]
    if len(keys) != 60:
        fail(errors, f"design.json has {len(keys)} keys, expected 60")
    positions = [(key["row"], key["col"]) for key in keys]
    if len(positions) != len(set(positions)):
        fail(errors, "matrix positions are not unique")
    if positions != [(r, c) for r in range(5) for c in range(12)]:
        fail(errors, "matrix positions are not the full 5 by 12 grid")

    row_gpios = [row["gpio"] for row in design["matrix"]["rows"]]
    col_gpios = [col["gpio"] for col in design["matrix"]["cols"]]
    all_gpios = row_gpios + col_gpios
    if len(all_gpios) != len(set(all_gpios)):
        fail(errors, f"GPIO pins overlap: {all_gpios}")
    unknown = [pin for pin in all_gpios if pin not in HEADER_GPIO]
    if unknown:
        fail(errors, f"GPIO pins are not Pico header pins: {unknown}")
    blocked = [pin for pin in all_gpios if pin in NOT_ON_HEADER]
    if blocked:
        fail(errors, f"GPIO pins are not available on the header: {blocked}")

    if design["matrix"]["diode_direction"] != "COL2ROW":
        fail(errors, "design diode direction is not COL2ROW")
    if keyboard.get("diode_direction") != "COL2ROW":
        fail(errors, "keyboard.json diode direction is not COL2ROW")
    if "banded end, connected to the row GPIO" not in design["matrix"]["cathode"]:
        fail(errors, "design.json cathode text does not point at the row")

    if keyboard["matrix_pins"]["rows"] != row_gpios:
        fail(errors, "keyboard.json row pins differ from design.json")
    if keyboard["matrix_pins"]["cols"] != col_gpios:
        fail(errors, "keyboard.json column pins differ from design.json")
    if keyboard.get("board") != "GENERIC_RP_RP2040":
        fail(errors, "keyboard.json board is not GENERIC_RP_RP2040")
    if keyboard.get("processor") != "RP2040" or keyboard.get("bootloader") != "rp2040":
        fail(errors, "keyboard.json processor or bootloader is not the Pico RP2040 target")
    if keyboard.get("debounce") != 5 or keyboard.get("build", {}).get("debounce_type") != "sym_defer_g":
        fail(errors, "debounce is not 5 ms sym_defer_g")
    features = keyboard.get("features", {})
    for name, expected in (("bootmagic", True), ("extrakey", True), ("nkro", True), ("console", False), ("mousekey", False)):
        if features.get(name) is not expected:
            fail(errors, f"feature {name} is {features.get(name)}, expected {expected}")
    if keyboard.get("bootmagic", {}).get("matrix") != [0, 0]:
        fail(errors, "bootmagic matrix is not [0, 0]")
    if keyboard.get("host", {}).get("default", {}).get("nkro") is not True:
        fail(errors, "NKRO is not the default")

    layout = keyboard["layouts"]["LAYOUT_ortho_5x12"]["layout"]
    if len(layout) != 60:
        fail(errors, f"layout has {len(layout)} keys")
    for key, item in zip(keys, layout):
        if item["matrix"] != [key["row"], key["col"]]:
            fail(errors, f"layout matrix mismatch at SW{key['id']}")
        if item.get("w") != 1 or item.get("h") != 1:
            fail(errors, f"SW{key['id']} is not a 1u key in keyboard.json")

    if len(layers) != 2:
        fail(errors, f"keymap has {len(layers)} layers, expected 2")
    else:
        base, fn = layers
        if base != [key["base_code"] for key in keys]:
            fail(errors, "base keymap does not match design.json in order")
        if fn != [key["fn_code"] for key in keys]:
            fail(errors, "Fn keymap does not match design.json in order")
        if len(base) != 60 or len(fn) != 60:
            fail(errors, "a keymap layer does not have 60 keycodes")

    rules = (KB / "rules.mk").read_text(encoding="utf-8")
    for line in rules.splitlines():
        code = line.split("#", 1)[0]
        if any(token in code for token in ("MATRIX", "BOOTLOADER", "BOARD", "MCU")):
            fail(errors, "rules.mk repeats hardware settings that belong in keyboard.json")
            break

    license_text = (ROOT / "LICENSE").read_text(encoding="utf-8")
    if "Copyright (c) 2026 Deonte Lamar Merritt" not in license_text:
        fail(errors, "MIT license is missing the required copyright line")
    if "Permission is hereby granted, free of charge" not in license_text:
        fail(errors, "LICENSE is not the MIT license text")
    copying = (KB / "COPYING").read_text(encoding="utf-8")
    if "GNU GENERAL PUBLIC LICENSE" not in copying or "Version 2, June 1991" not in copying:
        fail(errors, "firmware COPYING is not GPL version 2")
    if "SPDX-License-Identifier: GPL-2.0-or-later" not in keymap_text:
        fail(errors, "keymap.c is missing the GPL SPDX header")
    notices = (ROOT / "THIRD_PARTY_NOTICES.md").read_text(encoding="utf-8")
    if "GPL-2.0-or-later" not in notices or "0.34.6" not in notices:
        fail(errors, "THIRD_PARTY_NOTICES.md does not record the QMK license boundary")

    docs = {
        name: (ROOT / "docs" / name).read_text(encoding="utf-8")
        for name in (
            "hardware-specification.md",
            "wiring-guide.md",
            "key-layout.md",
            "build-flash-test-guide.md",
            "troubleshooting.md",
            "schematic-specification.md",
        )
    }
    combined = "\n".join(docs.values())
    for needle in (
        "COL2ROW",
        "Raspberry Pi Pico",
        "SC0915",
        "1N4148",
        "cathode",
        "BOOTSEL",
        "qmk compile -kb merritt/merritt60ii -km default",
        "GENERIC_RP_RP2040",
        "sym_defer_g",
    ):
        if needle not in combined:
            fail(errors, f"documentation is missing {needle!r}")
    for gpio in all_gpios:
        if gpio not in docs["hardware-specification.md"] or gpio not in docs["wiring-guide.md"]:
            fail(errors, f"{gpio} is missing from the hardware or wiring guide")
    if "charge-only" not in docs["troubleshooting.md"] and "charge-only" not in docs["build-flash-test-guide.md"]:
        fail(errors, "troubleshooting does not mention charge-only cables")
    for topic in ("Reversed diodes", "Incorrect GPIO", "Missing keypresses", "Repeated keypresses"):
        if topic not in docs["troubleshooting.md"]:
            fail(errors, f"troubleshooting is missing the section {topic}")

    table = matrix_rows_from_layout_doc(docs["key-layout.md"])
    if len(table) != 60:
        fail(errors, f"key-layout matrix table has {len(table)} rows")
    else:
        for key, row in zip(keys, table):
            if row["base"] != key["base_code"] or row["fn"] != key["fn_code"]:
                fail(errors, f"key-layout table disagrees with design.json at SW{key['id']}")
            if row["row_gpio"] != key["row_gpio"] or row["col_gpio"] != key["col_gpio"]:
                fail(errors, f"key-layout GPIO disagrees at SW{key['id']}")
            if row["keycap"] != "1u":
                fail(errors, f"SW{key['id']} keycap is not 1u")

    readme = (ROOT / "README.md").read_text(encoding="utf-8")
    if "MIT" not in readme or "GPL-2.0-or-later" not in readme:
        fail(errors, "README license section is incomplete")
    if "PlatformIO" not in readme:
        fail(errors, "README does not explain the absence of PlatformIO firmware")
    if "Seldun" not in readme:
        fail(errors, "README does not explain typing source code on the computer")

    bom = (ROOT / "docs" / "bill-of-materials.csv").read_text(encoding="utf-8")
    if ",60,SW1-SW60," not in bom or ",60,D1-D60," not in bom:
        fail(errors, "bill of materials does not list 60 switches and 60 diodes")

    netlist_path = OUT_NETLIST if (OUT_NETLIST := ROOT / "hardware" / "kicad" / "merritt60ii.net").is_file() else None
    if netlist_path:
        check_kicad_netlist(netlist_path.read_text(encoding="utf-8"), errors, notes)
    else:
        notes.append("KiCad netlist not found; schematic connectivity was not checked in this run.")

    print(f"errors: {len(errors)}")
    for message in errors:
        print(f"ERROR {message}")
    for message in notes:
        print(f"NOTE {message}")
    return 1 if errors else 0


def check_kicad_netlist(text: str, errors: list[str], notes: list[str]) -> None:
    import re
    nets: dict[str, set[tuple[str, str]]] = {}
    current = None
    for line in text.splitlines():
        named = re.search(r'\(net \(code "[^"]+"\) \(name "([^"]+)"\)', line)
        if named:
            current = named.group(1).lstrip("/")
            nets.setdefault(current, set())
            continue
        node = re.search(r'\(node \(ref "([^"]+)"\) \(pin "([^"]+)"\)', line)
        if node and current:
            nets[current].add((node.group(1), node.group(2)))
    notes.append(f"KiCad netlist has {len(nets)} nets")
    if not any(name.startswith("ROW") for name in nets):
        fail(errors, "KiCad netlist has no ROW nets; export may have failed to connect labels")
        return
    for row in range(5):
        nodes = nets.get(f"ROW{row}", set())
        expected_pin = {0: "4", 1: "5", 2: "6", 3: "7", 4: "9"}[row]
        if ("U1", expected_pin) not in nodes:
            fail(errors, f"ROW{row} is not tied to Pico pin {expected_pin}")
        cathodes = {ref for ref, pin in nodes if ref.startswith("D") and pin == "1"}
        if len(cathodes) != 12:
            fail(errors, f"ROW{row} has {len(cathodes)} diode cathodes, expected 12")
    for col in range(12):
        nodes = nets.get(f"COL{col}", set())
        expected_pin = {0: "10", 1: "11", 2: "12", 3: "14", 4: "15", 5: "16", 6: "17", 7: "19", 8: "20", 9: "21", 10: "22", 11: "24"}[col]
        if ("U1", expected_pin) not in nodes:
            fail(errors, f"COL{col} is not tied to Pico pin {expected_pin}")
        switches = {ref for ref, pin in nodes if ref.startswith("SW") and pin == "1"}
        if len(switches) != 5:
            fail(errors, f"COL{col} has {len(switches)} switches, expected 5")
    for number in range(1, 61):
        nodes = nets.get(f"K{number}", set())
        if (f"SW{number}", "2") not in nodes or (f"D{number}", "2") not in nodes:
            fail(errors, f"K{number} does not join the switch and the diode anode")
        if len(nodes) != 2:
            fail(errors, f"K{number} touches {len(nodes)} pins, expected 2")


if __name__ == "__main__":
    sys.exit(main())
