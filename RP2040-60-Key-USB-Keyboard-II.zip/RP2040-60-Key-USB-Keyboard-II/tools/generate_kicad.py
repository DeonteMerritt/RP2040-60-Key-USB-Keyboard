#!/usr/bin/env python3
# Copyright 2026 Deonte Lamar Merritt
# SPDX-License-Identifier: MIT
"""Write an editable KiCad 7 schematic of the Pico module matrix.

The schematic is the hand-wired Raspberry Pi Pico design. It is not a
bare-RP2040 board and it is not manufacturing data. Symbols are original
drawings for this project.
"""

from __future__ import annotations

import uuid
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "hardware" / "kicad"
SHEET = "7c1a9e2b-4d5f-4a61-9c3e-1b8d60a2f417"
PROJECT = "merritt60ii"

# Silkscreen pin -> name. Pin 1 is next to the USB connector.
PICO_PINS = {
    1: "GP0", 2: "GP1", 3: "GND", 4: "GP2", 5: "GP3", 6: "GP4", 7: "GP5",
    8: "GND", 9: "GP6", 10: "GP7", 11: "GP8", 12: "GP9", 13: "GND", 14: "GP10",
    15: "GP11", 16: "GP12", 17: "GP13", 18: "GND", 19: "GP14", 20: "GP15",
    21: "GP16", 22: "GP17", 23: "GND", 24: "GP18", 25: "GP19", 26: "GP20",
    27: "GP21", 28: "GND", 29: "GP22", 30: "RUN", 31: "GP26", 32: "GP27",
    33: "AGND", 34: "GP28", 35: "ADC_VREF", 36: "3V3", 37: "3V3_EN",
    38: "GND", 39: "VSYS", 40: "VBUS",
}
ROW_PINS = {0: 4, 1: 5, 2: 6, 3: 7, 4: 9}
COL_PINS = {0: 10, 1: 11, 2: 12, 3: 14, 4: 15, 5: 16, 6: 17, 7: 19, 8: 20, 9: 21, 10: 22, 11: 24}


def uid() -> str:
    return str(uuid.uuid4())


def prop(name: str, value: str, x: float, y: float, hide: bool = False) -> str:
    hidden = " hide" if hide else ""
    return (
        f'    (property "{name}" "{value}" (at {x} {y} 0)\n'
        f'      (effects (font (size 1.27 1.27)){hidden})\n'
        f"    )"
    )


def pico_symbol() -> str:
    pins = []
    for number in range(1, 21):
        y = 24.13 - (number - 1) * 2.54
        pins.append(
            f'      (pin passive line (at -15.24 {y:.2f} 180) (length 2.54)\n'
            f'        (name "{PICO_PINS[number]}" (effects (font (size 1.27 1.27))))\n'
            f'        (number "{number}" (effects (font (size 1.27 1.27))))\n'
            f"      )"
        )
    for number in range(21, 41):
        y = 24.13 - (40 - number) * 2.54
        pins.append(
            f'      (pin passive line (at 15.24 {y:.2f} 0) (length 2.54)\n'
            f'        (name "{PICO_PINS[number]}" (effects (font (size 1.27 1.27))))\n'
            f'        (number "{number}" (effects (font (size 1.27 1.27))))\n'
            f"      )"
        )
    pin_text = "\n".join(pins)
    return f"""  (symbol "merritt60:Raspberry_Pi_Pico" (in_bom yes) (on_board yes)
    (property "Reference" "U" (at 0 27.94 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Value" "Raspberry_Pi_Pico" (at 0 -27.94 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Footprint" "" (at 0 0 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "https://datasheets.raspberrypi.com/pico/pico-datasheet.pdf" (at 0 0 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ki_description" "Raspberry Pi Pico module, 40 header pins, built-in micro-USB" (at 0 0 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (symbol "Raspberry_Pi_Pico_0_1"
      (rectangle (start -12.7 26.67) (end 12.7 -26.67)
        (stroke (width 0.254) (type default))
        (fill (type background))
      )
    )
    (symbol "Raspberry_Pi_Pico_1_1"
{pin_text}
    )
  )"""


def diode_symbol() -> str:
    return """  (symbol "merritt60:D_1N4148" (pin_names hide) (in_bom yes) (on_board yes)
    (property "Reference" "D" (at 0 2.54 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Value" "1N4148" (at 0 -2.54 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Footprint" "Diode_THT:D_DO-35_SOD27_P7.62mm_Horizontal" (at 0 0 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "~" (at 0 0 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (symbol "D_1N4148_0_1"
      (polyline (pts (xy -1.27 1.27) (xy -1.27 -1.27)) (stroke (width 0.254) (type default)) (fill (type none)))
      (polyline (pts (xy 1.27 1.27) (xy 1.27 -1.27) (xy -1.27 0) (xy 1.27 1.27)) (stroke (width 0.254) (type default)) (fill (type none)))
    )
    (symbol "D_1N4148_1_1"
      (pin passive line (at -3.81 0 0) (length 2.54)
        (name "K" (effects (font (size 1.27 1.27))))
        (number "1" (effects (font (size 1.27 1.27))))
      )
      (pin passive line (at 3.81 0 180) (length 2.54)
        (name "A" (effects (font (size 1.27 1.27))))
        (number "2" (effects (font (size 1.27 1.27))))
      )
    )
  )"""


def switch_symbol() -> str:
    return """  (symbol "merritt60:SW_Key" (pin_names hide) (in_bom yes) (on_board yes)
    (property "Reference" "SW" (at 0 3.81 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Value" "SW_Key" (at 0 -3.81 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Footprint" "Button_Switch_Keyboard:SW_Cherry_MX_1.00u_PCB" (at 0 0 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "~" (at 0 0 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (symbol "SW_Key_0_1"
      (circle (center 0 0) (radius 2.54) (stroke (width 0.254) (type default)) (fill (type none)))
    )
    (symbol "SW_Key_1_1"
      (pin passive line (at -5.08 0 0) (length 2.54)
        (name "1" (effects (font (size 1.27 1.27))))
        (number "1" (effects (font (size 1.27 1.27))))
      )
      (pin passive line (at 5.08 0 180) (length 2.54)
        (name "2" (effects (font (size 1.27 1.27))))
        (number "2" (effects (font (size 1.27 1.27))))
      )
    )
  )"""


def symbol_instance(lib_id: str, ref: str, value: str, x: float, y: float, angle: int, pins: list[str], footprint: str) -> str:
    pin_lines = "\n".join(f'    (pin "{pin}" (uuid {uid()}))' for pin in pins)
    return f"""  (symbol (lib_id "{lib_id}") (at {x:.2f} {y:.2f} {angle}) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid {uid()})
    (property "Reference" "{ref}" (at {x:.2f} {y + 5.08:.2f} 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Value" "{value}" (at {x:.2f} {y - 5.08:.2f} 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Footprint" "{footprint}" (at {x:.2f} {y:.2f} 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "~" (at {x:.2f} {y:.2f} 0)
      (effects (font (size 1.27 1.27)) hide)
    )
{pin_lines}
    (instances
      (project "{PROJECT}"
        (path "/{SHEET}"
          (reference "{ref}") (unit 1)
        )
      )
    )
  )"""


def label(name: str, x: float, y: float) -> str:
    return (
        f'  (label "{name}" (at {x:.2f} {y:.2f} 0)\n'
        f"    (effects (font (size 1.27 1.27)) (justify left bottom))\n"
        f"    (uuid {uid()})\n"
        f"  )"
    )


def no_connect(x: float, y: float) -> str:
    return f"  (no_connect (at {x:.2f} {y:.2f}) (uuid {uid()}))"


def pico_pin_xy(origin_x: float, origin_y: float, number: int) -> tuple[float, float]:
    """Schematic position of a Pico header pin.

    KiCad 7 places symbol pin coordinates with Y negated relative to the
    numbers stored in the symbol. Labels have to use that placed position.
    """
    if number <= 20:
        local_x = -15.24
        local_y = 24.13 - (number - 1) * 2.54
    else:
        local_x = 15.24
        local_y = 24.13 - (40 - number) * 2.54
    return origin_x + local_x, origin_y - local_y


def schematic() -> str:
    px, py = 40.64, 170.18
    parts = [
        symbol_instance(
            "merritt60:Raspberry_Pi_Pico",
            "U1",
            "Raspberry_Pi_Pico",
            px,
            py,
            0,
            [str(n) for n in range(1, 41)],
            "",
        )
    ]
    labels = []
    opens = []
    used = set(ROW_PINS.values()) | set(COL_PINS.values())
    for number in range(1, 41):
        x, y = pico_pin_xy(px, py, number)
        if number in ROW_PINS.values():
            row = next(r for r, pin in ROW_PINS.items() if pin == number)
            labels.append(label(f"ROW{row}", x, y))
        elif number in COL_PINS.values():
            col = next(c for c, pin in COL_PINS.items() if pin == number)
            labels.append(label(f"COL{col}", x, y))
        else:
            opens.append(no_connect(x, y))

    for index in range(60):
        row, col = divmod(index, 12)
        number = index + 1
        sx = 120.65 + col * 30.48
        sy = 200.66 - row * 25.40
        dx = sx + 8.89
        parts.append(
            symbol_instance(
                "merritt60:SW_Key",
                f"SW{number}",
                "SW_Key",
                sx,
                sy,
                0,
                ["1", "2"],
                "Button_Switch_Keyboard:SW_Cherry_MX_1.00u_PCB",
            )
        )
        parts.append(
            symbol_instance(
                "merritt60:D_1N4148",
                f"D{number}",
                "1N4148",
                dx,
                sy,
                180,
                ["1", "2"],
                "Diode_THT:D_DO-35_SOD27_P7.62mm_Horizontal",
            )
        )
        labels.append(label(f"COL{col}", sx - 5.08, sy))
        labels.append(label(f"K{number}", sx + 5.08, sy))
        labels.append(label(f"ROW{row}", dx + 3.81, sy))

    note = (
        '  (text "Hand-wired Raspberry Pi Pico module. Cathode (diode pin 1, band) is the row net. '
        'COL2ROW. Not a bare RP2040 PCB. Not manufacturing-ready." (at 120.65 230.00 0)\n'
        "    (effects (font (size 1.27 1.27)))\n"
        f"    (uuid {uid()})\n"
        "  )"
    )
    body = "\n".join(parts + labels + opens + [note])
    return f"""(kicad_sch (version 20230121) (generator eeschema)
  (uuid {SHEET})
  (paper "A1")
  (title_block
    (title "RP2040 60-Key USB Keyboard II")
    (date "2026-10-02")
    (rev "II")
    (company "Merritt Robotics Inc.")
    (comment 1 "Raspberry Pi Pico module plus 5x12 diode matrix. Not a bare RP2040.")
    (comment 2 "Diode pin 1 is the cathode and connects to the row. Firmware COL2ROW.")
    (comment 3 "Not manufacturing-ready. Copyright 2026 Deonte Lamar Merritt. MIT.")
  )
  (lib_symbols
{pico_symbol()}
{diode_symbol()}
{switch_symbol()}
  )
{body}
  (sheet_instances
    (path "/" (page "1"))
  )
)
"""


def project_file() -> str:
    return """{
  "board": {
    "design_settings": {
      "rules": {
        "min_clearance": 0.2
      }
    }
  },
  "meta": {
    "filename": "merritt60ii.kicad_pro",
    "version": 1
  },
  "sheets": [
    ["merritt60ii.kicad_sch", ""]
  ]
}
"""


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "merritt60ii.kicad_sch").write_text(schematic(), encoding="utf-8")
    (OUT / "merritt60ii.kicad_pro").write_text(project_file(), encoding="utf-8")
    print(f"Wrote {OUT / 'merritt60ii.kicad_sch'}")


if __name__ == "__main__":
    main()
