# Key layout

Sixty physical keys, five rows by twelve columns, ortholinear, every key 1u (19.05 mm pitch). Row 0 is the top. Column 0 is the left. There is no wide spacebar and no stabilizer.

The keymap QMK compiles is `firmware/qmk/keyboards/merritt/merritt60ii/keymaps/default/keymap.c`. The matrix positions below are the same positions `keyboard.json` gives to `LAYOUT_ortho_5x12`.

## Base layer

This is what the keycaps should say, and what the key sends when Fn is not held.

```
`    1    2    3    4    5    6    7    8    9    0    Backspace
Tab  Q    W    E    R    T    Y    U    I    O    P    \
Esc  A    S    D    F    G    H    J    K    L    ;    '
Shift Z   X    C    V    B    N    M    ,    .    /    Enter
Ctrl Win  Alt  Fn   [    ]    Space -  =    Fn   Del  Shift
```

The Win key sends Left GUI. Windows treats that as the Windows key, Linux as Super, and macOS as Command. The keycap can say Win.

Hold either Fn key for the function layer. Both Fn keys are the same momentary layer.

## Characters used in source code

Shifted symbols come from the Shift key plus the base key. They are not missing keys.

| Key | With Shift |
| --- | --- |
| `` ` `` | `~` |
| `1`–`0` | `! @ # $ % ^ & * ( )` |
| `-` | `_` |
| `=` | `+` |
| `[` | `{` |
| `]` | `}` |
| `\` | `|` |
| `;` | `:` |
| `'` | `"` |
| `,` | `<` |
| `.` | `>` |
| `/` | `?` |

That set is enough to type Seldun, Java, Python, JavaScript, C++, and other source code into an editor. The keyboard sends USB HID keycodes. The computer compiles and runs the program.

## Fn layer

Hold Fn, then press the key. A dash means the base key still works while Fn is held, because that position is transparent (`_______`) in the keymap.

```
Boot F1   F2   F3   F4   F5   F6   F7   F8   F9   F10  Del
F11  F12  PrtSc ScrLk Pause —  Home PgDn PgUp End  Ins  —
—    —    —    —    —    —    Left Down Up   Right —   —
—    —    —    —    —    —    —    —    Mute Vol- Vol+ —
—    —    —    —    —    —    —    —    —    —    PgUp PgDn
```

Arrow keys are Fn+H, Fn+J, Fn+K, and Fn+L (Left, Down, Up, Right).

Navigation is Fn+Y Home, Fn+U Page Down, Fn+I Page Up, Fn+O End, Fn+P Insert. Fn+Backspace is Delete. The bottom-right Del key becomes Page Up while Fn is held, and the right Shift becomes Page Down.

Function keys are Fn+1 through Fn+0 for F1 through F10, Fn+Tab for F11, and Fn+Q for F12.

Fn+comma mutes, Fn+period lowers volume, and Fn+slash raises volume. Those are consumer HID keys. The firmware enables QMK's extrakey feature so the host receives them.

## Bootloader key

Fn plus the top-left key (the grave key) is `QK_BOOT`. That reboots the RP2040 into the UF2 bootloader. Holding that same physical key while plugging in the cable also enters the bootloader, because Bootmagic watches matrix position `[0, 0]`.

## Modifiers and simultaneous keys

Ctrl, Shift, Alt, and Win are real HID modifiers. They combine with other keys, including Ctrl+Shift+key. NKRO is enabled and is the default, so the report is not limited to six simultaneous keys on hosts that use the NKRO interface. The diodes keep those simultaneous presses from ghosting.

The operating system repeats a key that you hold down. That repeat is the computer, not a second make code from a bouncing switch. Bounce is handled by the 5 ms debounce in the firmware.

## Keycaps

Order 60 keycaps, each 1u, MX cross mount. Use a uniform profile (DSA, XDA, or a single OEM row for every key) so the ortholinear grid is one height. Do not include a spacebar, a 2u shift, or stabilizers.

Two caps say Shift, two say Fn, and one each of Ctrl, Win, Alt, Space, Enter, Tab, Esc, Backspace, and Del. The remaining caps are the letters, digits, and punctuation in the base-layer drawing.

## Matrix position table

Designators SW1 and D1 are the top-left key. Numbers increase across the row, then down. Diodes D1–D60 match SW1–SW60. The cathode of each diode is on the row GPIO in that row.

<!-- BEGIN MATRIX TABLE -->
| ID | Row | Col | Legend | Base keycode | Fn action | Fn keycode | Row GPIO | Pico row pin | Col GPIO | Pico col pin | Keycap |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| SW1 / D1 | 0 | 0 | ` | `KC_GRV` | Boot | `QK_BOOT` | GP2 | 4 | GP7 | 10 | 1u |
| SW2 / D2 | 0 | 1 | 1 | `KC_1` | F1 | `KC_F1` | GP2 | 4 | GP8 | 11 | 1u |
| SW3 / D3 | 0 | 2 | 2 | `KC_2` | F2 | `KC_F2` | GP2 | 4 | GP9 | 12 | 1u |
| SW4 / D4 | 0 | 3 | 3 | `KC_3` | F3 | `KC_F3` | GP2 | 4 | GP10 | 14 | 1u |
| SW5 / D5 | 0 | 4 | 4 | `KC_4` | F4 | `KC_F4` | GP2 | 4 | GP11 | 15 | 1u |
| SW6 / D6 | 0 | 5 | 5 | `KC_5` | F5 | `KC_F5` | GP2 | 4 | GP12 | 16 | 1u |
| SW7 / D7 | 0 | 6 | 6 | `KC_6` | F6 | `KC_F6` | GP2 | 4 | GP13 | 17 | 1u |
| SW8 / D8 | 0 | 7 | 7 | `KC_7` | F7 | `KC_F7` | GP2 | 4 | GP14 | 19 | 1u |
| SW9 / D9 | 0 | 8 | 8 | `KC_8` | F8 | `KC_F8` | GP2 | 4 | GP15 | 20 | 1u |
| SW10 / D10 | 0 | 9 | 9 | `KC_9` | F9 | `KC_F9` | GP2 | 4 | GP16 | 21 | 1u |
| SW11 / D11 | 0 | 10 | 0 | `KC_0` | F10 | `KC_F10` | GP2 | 4 | GP17 | 22 | 1u |
| SW12 / D12 | 0 | 11 | Backspace | `KC_BSPC` | Del | `KC_DEL` | GP2 | 4 | GP18 | 24 | 1u |
| SW13 / D13 | 1 | 0 | Tab | `KC_TAB` | F11 | `KC_F11` | GP3 | 5 | GP7 | 10 | 1u |
| SW14 / D14 | 1 | 1 | Q | `KC_Q` | F12 | `KC_F12` | GP3 | 5 | GP8 | 11 | 1u |
| SW15 / D15 | 1 | 2 | W | `KC_W` | PrtSc | `KC_PSCR` | GP3 | 5 | GP9 | 12 | 1u |
| SW16 / D16 | 1 | 3 | E | `KC_E` | ScrLk | `KC_SCRL` | GP3 | 5 | GP10 | 14 | 1u |
| SW17 / D17 | 1 | 4 | R | `KC_R` | Pause | `KC_PAUS` | GP3 | 5 | GP11 | 15 | 1u |
| SW18 / D18 | 1 | 5 | T | `KC_T` | — | `_______` | GP3 | 5 | GP12 | 16 | 1u |
| SW19 / D19 | 1 | 6 | Y | `KC_Y` | Home | `KC_HOME` | GP3 | 5 | GP13 | 17 | 1u |
| SW20 / D20 | 1 | 7 | U | `KC_U` | PgDn | `KC_PGDN` | GP3 | 5 | GP14 | 19 | 1u |
| SW21 / D21 | 1 | 8 | I | `KC_I` | PgUp | `KC_PGUP` | GP3 | 5 | GP15 | 20 | 1u |
| SW22 / D22 | 1 | 9 | O | `KC_O` | End | `KC_END` | GP3 | 5 | GP16 | 21 | 1u |
| SW23 / D23 | 1 | 10 | P | `KC_P` | Ins | `KC_INS` | GP3 | 5 | GP17 | 22 | 1u |
| SW24 / D24 | 1 | 11 | \ | `KC_BSLS` | — | `_______` | GP3 | 5 | GP18 | 24 | 1u |
| SW25 / D25 | 2 | 0 | Esc | `KC_ESC` | — | `_______` | GP4 | 6 | GP7 | 10 | 1u |
| SW26 / D26 | 2 | 1 | A | `KC_A` | — | `_______` | GP4 | 6 | GP8 | 11 | 1u |
| SW27 / D27 | 2 | 2 | S | `KC_S` | — | `_______` | GP4 | 6 | GP9 | 12 | 1u |
| SW28 / D28 | 2 | 3 | D | `KC_D` | — | `_______` | GP4 | 6 | GP10 | 14 | 1u |
| SW29 / D29 | 2 | 4 | F | `KC_F` | — | `_______` | GP4 | 6 | GP11 | 15 | 1u |
| SW30 / D30 | 2 | 5 | G | `KC_G` | — | `_______` | GP4 | 6 | GP12 | 16 | 1u |
| SW31 / D31 | 2 | 6 | H | `KC_H` | Left | `KC_LEFT` | GP4 | 6 | GP13 | 17 | 1u |
| SW32 / D32 | 2 | 7 | J | `KC_J` | Down | `KC_DOWN` | GP4 | 6 | GP14 | 19 | 1u |
| SW33 / D33 | 2 | 8 | K | `KC_K` | Up | `KC_UP` | GP4 | 6 | GP15 | 20 | 1u |
| SW34 / D34 | 2 | 9 | L | `KC_L` | Right | `KC_RGHT` | GP4 | 6 | GP16 | 21 | 1u |
| SW35 / D35 | 2 | 10 | ; | `KC_SCLN` | — | `_______` | GP4 | 6 | GP17 | 22 | 1u |
| SW36 / D36 | 2 | 11 | ' | `KC_QUOT` | — | `_______` | GP4 | 6 | GP18 | 24 | 1u |
| SW37 / D37 | 3 | 0 | Shift | `KC_LSFT` | — | `_______` | GP5 | 7 | GP7 | 10 | 1u |
| SW38 / D38 | 3 | 1 | Z | `KC_Z` | — | `_______` | GP5 | 7 | GP8 | 11 | 1u |
| SW39 / D39 | 3 | 2 | X | `KC_X` | — | `_______` | GP5 | 7 | GP9 | 12 | 1u |
| SW40 / D40 | 3 | 3 | C | `KC_C` | — | `_______` | GP5 | 7 | GP10 | 14 | 1u |
| SW41 / D41 | 3 | 4 | V | `KC_V` | — | `_______` | GP5 | 7 | GP11 | 15 | 1u |
| SW42 / D42 | 3 | 5 | B | `KC_B` | — | `_______` | GP5 | 7 | GP12 | 16 | 1u |
| SW43 / D43 | 3 | 6 | N | `KC_N` | — | `_______` | GP5 | 7 | GP13 | 17 | 1u |
| SW44 / D44 | 3 | 7 | M | `KC_M` | — | `_______` | GP5 | 7 | GP14 | 19 | 1u |
| SW45 / D45 | 3 | 8 | , | `KC_COMM` | Mute | `KC_MUTE` | GP5 | 7 | GP15 | 20 | 1u |
| SW46 / D46 | 3 | 9 | . | `KC_DOT` | Vol- | `KC_VOLD` | GP5 | 7 | GP16 | 21 | 1u |
| SW47 / D47 | 3 | 10 | / | `KC_SLSH` | Vol+ | `KC_VOLU` | GP5 | 7 | GP17 | 22 | 1u |
| SW48 / D48 | 3 | 11 | Enter | `KC_ENT` | — | `_______` | GP5 | 7 | GP18 | 24 | 1u |
| SW49 / D49 | 4 | 0 | Ctrl | `KC_LCTL` | — | `_______` | GP6 | 9 | GP7 | 10 | 1u |
| SW50 / D50 | 4 | 1 | Win | `KC_LGUI` | — | `_______` | GP6 | 9 | GP8 | 11 | 1u |
| SW51 / D51 | 4 | 2 | Alt | `KC_LALT` | — | `_______` | GP6 | 9 | GP9 | 12 | 1u |
| SW52 / D52 | 4 | 3 | Fn | `MO(_FN)` | — | `_______` | GP6 | 9 | GP10 | 14 | 1u |
| SW53 / D53 | 4 | 4 | [ | `KC_LBRC` | — | `_______` | GP6 | 9 | GP11 | 15 | 1u |
| SW54 / D54 | 4 | 5 | ] | `KC_RBRC` | — | `_______` | GP6 | 9 | GP12 | 16 | 1u |
| SW55 / D55 | 4 | 6 | Space | `KC_SPC` | — | `_______` | GP6 | 9 | GP13 | 17 | 1u |
| SW56 / D56 | 4 | 7 | - | `KC_MINS` | — | `_______` | GP6 | 9 | GP14 | 19 | 1u |
| SW57 / D57 | 4 | 8 | = | `KC_EQL` | — | `_______` | GP6 | 9 | GP15 | 20 | 1u |
| SW58 / D58 | 4 | 9 | Fn | `MO(_FN)` | — | `_______` | GP6 | 9 | GP16 | 21 | 1u |
| SW59 / D59 | 4 | 10 | Del | `KC_DEL` | PgUp | `KC_PGUP` | GP6 | 9 | GP17 | 22 | 1u |
| SW60 / D60 | 4 | 11 | Shift | `KC_RSFT` | PgDn | `KC_PGDN` | GP6 | 9 | GP18 | 24 | 1u |
<!-- END MATRIX TABLE -->
