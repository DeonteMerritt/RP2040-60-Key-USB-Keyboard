# Validation report

Prepared for the RP2040 60-Key USB Keyboard II (Merritt Robotics Inc.). This report separates three different kinds of evidence:

1. Source validation — files and tables in this repository were checked against each other.
2. Firmware compilation — a QMK build on a computer, which produces a UF2 if it succeeds.
3. Physical hardware testing — a real Pico, a wired matrix, and a host computer. That was not done.

## Inspection of the existing repository

The repository contained one commit, an empty project initialization. These paths were absent:

- `platformio.ini`
- `src/`
- `firmware/`
- `wiring/`
- `schematic/`
- `docs/`
- `firmware/qmk/keyboards/merritt/merritt60` (`info.json`, `rules.mk`, and keymaps)

There was no original controller board, matrix, keymap, dependency list, or firmware to preserve. There was no serial-only scanner and no USB keyboard implementation. This folder is a new design. It does not replace an earlier project.

## Source validation

Command:

```bash
python3 tools/validate_design.py
```

Working directory: `rp2040-60-key-usb-keyboard-ii`.

Result:

```text
errors: 0
NOTE KiCad netlist has 100 nets
```

Exit code: 0.

The script checked, and these statements match the files it read:

- Exactly 60 keys, positions `(row, column)` for rows 0–4 and columns 0–11, each position used once.
- Row GPIOs GP2, GP3, GP4, GP5, GP6 and column GPIOs GP7–GP18 are unique, are header pins on the Raspberry Pi Pico, and are not GP23, GP24, GP25, or GP29.
- `keyboard.json` sets `diode_direction` to `COL2ROW`. Documentation says the 1N4148 cathode (banded end) connects to the row. Columns are driven low; rows are inputs with pull-ups; a pressed switch reads as 0.
- `LAYOUT_ortho_5x12` lists the same 60 matrix positions in the same order as the physical layout, each key 1u.
- `keymaps/default/keymap.c` assigns the same base and Fn keycodes as `hardware/design.json`, including modifiers, `MO(_FN)`, and `QK_BOOT`.
- Board is `GENERIC_RP_RP2040`, processor `RP2040`, bootloader `rp2040`, debounce 5 ms, debounce type `sym_defer_g`, NKRO enabled and on by default, console off, Bootmagic matrix `[0, 0]`.
- `rules.mk` does not repeat pin, board, or bootloader settings.
- Required project files are present, including the QMK keyboard definition, default keymap, `COPYING` (GPL version 2), both `LICENSE` files (MIT, `Copyright (c) 2026 Deonte Lamar Merritt`), and the documents listed in the project README.
- Hardware specification, wiring guide, key-layout table, bill of materials (60 switches SW1–SW60, 60 diodes D1–D60), and troubleshooting text agree with those GPIO names, the Pico part number SC0915, and the build command `qmk compile -kb merritt/merritt60ii -km default`.

This is a consistency check of the repository. It does not flash a board.

## Schematic netlist

KiCad 7.0.11 is installed. Its command-line tool can export a netlist. It does not provide `sch erc` or `pcb drc` (those commands arrived in later KiCad releases). No electrical-rules check and no design-rules check were run.

Command:

```bash
kicad-cli sch export netlist --format kicadsexpr \
  -o hardware/kicad/merritt60ii.net \
  hardware/kicad/merritt60ii.kicad_sch
```

The exported netlist contains 100 nets. `tools/validate_design.py` parsed the named matrix nets and checked:

- Each column net `COL0`–`COL11` includes the matching Pico header pin (COL0 is U1 pin 10, GP7; COL11 is U1 pin 24, GP18) and the five switch pin-1 nodes in that column.
- Each row net `ROW0`–`ROW4` includes the matching Pico row pin and twelve diode pin-1 nodes (cathodes).
- Each key net `K1`–`K60` joins that switch's pin 2 to that diode's pin 2 (anode).

The schematic is an editable record of the Pico-module wiring. It is not a routed PCB, and it is not manufacturing data. A future board that uses a bare RP2040 still needs a crystal, flash, regulator, USB connector, series resistors, BOOTSEL and reset circuitry, decoupling, a verified footprint, routing, and KiCad ERC/DRC before anyone sends files to a board house.

## Firmware compilation

Compiled successfully. This is a software build only. The UF2 was not copied to a Pico.

Toolchain on the build machine:

- QMK Firmware tag `0.34.6`, commit `d9f6dd215f2c4d295c6ad85b1f602125c2d81db1`
- QMK CLI 1.2.0
- `arm-none-eabi-gcc (15:13.2.rel1-2) 13.2.1 20231009`

The keyboard folder was linked into a local QMK tree:

```bash
mkdir -p keyboards/merritt
ln -sfn /path/to/rp2040-60-key-usb-keyboard-ii/firmware/qmk/keyboards/merritt/merritt60ii \
  keyboards/merritt/merritt60ii
```

First command, from the QMK tree, with `qmk` on `PATH`:

```bash
qmk compile -kb merritt/merritt60ii -km default
```

That attempt stopped while compiling `tmk_core/protocol/chibios/usb_main.c`:

```text
fatal error: lib/lufa/LUFA/Drivers/USB/Class/Common/HIDClassCommon.h: No such file or directory
gmake: *** [builddefs/common_rules.mk:369: .build/obj_merritt_merritt60ii_default/protocol/chibios/usb_main.o] Error 1
```

The QMK checkout had not initialized `lib/lufa`. That is a missing QMK submodule, not a defect in the keyboard definition. It was fetched with:

```bash
git submodule update --init --depth 1 lib/lufa
```

Checked out commit `549b97320d515bfca2f95c145a67bd13be968faa`. A normal `qmk setup` on Windows initializes this submodule; the shallow clone used here did not.

Second command, same compile line:

```bash
qmk compile -kb merritt/merritt60ii -km default
```

Exit code: 0. The log ends with:

```text
Linking: .build/merritt_merritt60ii_default.elf                                                     [OK]
Creating UF2 file for deployment: .build/merritt_merritt60ii_default.uf2                            [OK]
Copying merritt_merritt60ii_default.uf2 to qmk_firmware folder                                      [OK]
```

Artifacts:

| File | Size |
| --- | --- |
| `merritt_merritt60ii_default.uf2` | 55,808 bytes |
| `.build/merritt_merritt60ii_default.elf` | 87,988 bytes |

`arm-none-eabi-size` on the ELF:

```text
   text    data     bss     dec     hex filename
  27892       0  265864  293756   47b7c .build/merritt_merritt60ii_default.elf
```

QMK's generated `info_config.h` for this build contains:

- `MATRIX_ROW_PINS { GP2, GP3, GP4, GP5, GP6 }`
- `MATRIX_COL_PINS { GP7, GP8, GP9, GP10, GP11, GP12, GP13, GP14, GP15, GP16, GP17, GP18 }`
- `DIODE_DIRECTION COL2ROW`
- `DEBOUNCE 5`
- `BOOTMAGIC_ROW 0` and `BOOTMAGIC_COLUMN 0`
- `NKRO_DEFAULT_ON true`
- `MANUFACTURER "Merritt Robotics Inc."`
- `PRODUCT "RP2040 60-Key USB Keyboard II"`
- `VENDOR_ID 0xFEED` and `PRODUCT_ID 0x4D60`

The link includes the ChibiOS USB device stack (`usb_main.c`, `usb_driver.c`, `usb_descriptor.c`, `hal_usb_lld.c`). That is the HID keyboard path. Console output was not enabled, so this firmware is not a serial matrix logger.

The UF2 is a build product and is not stored in this repository. Build it again with the command above when you are ready to flash.

## Physical hardware testing

Not performed. No Raspberry Pi Pico was connected, no UF2 was copied to an RPI-RP2 drive, and no switch was pressed. Do not treat the keyboard as electrically tested or as confirmed to type on a host.
