# Troubleshooting

Work from the top of this list. Most "dead keyboard" reports on a new Pico are the cable or the bootloader, not the keymap.

## USB data cables

The Pico's socket is micro-USB. The cable must carry data.

- A charge-only cable can power the LED side of some boards and still never show `RPI-RP2` or a keyboard. Try a second cable that you have used to copy files to a phone or a development board.
- Plug into a USB port on the computer, not the monitor or an unpowered hub, until the keyboard is known to work.
- Seat the plug fully. The Pico's connector is small and easy to leave half inserted.

## The computer does not see a device

What you should see depends on the mode:

| Situation | What Windows should show |
| --- | --- |
| BOOTSEL held while plugging in, or a blank Pico | A drive named `RPI-RP2` |
| Firmware flashed, cable plugged in normally | A HID keyboard, and typing in Notepad |

If neither appears:

1. Confirm the cable is a data cable, on a port on the PC.
2. Enter BOOTSEL again: unplug, hold BOOTSEL, plug in, then release.
3. Look in File Explorer for `RPI-RP2`, not only in Device Manager. The bootloader is a USB disk.
4. If `RPI-RP2` appears but copying the UF2 does nothing, copy `merritt_merritt60ii_default.uf2` only. Do not copy the `.elf` or a hex file. The name must end in `.uf2`.
5. If the drive never comes back after a bad flash, BOOTSEL still works. The ROM bootloader does not depend on the keyboard firmware.

Holding the top-left key at plug-in, after a successful flash, also enters the bootloader. If that key is shorted by a solder bridge, every plug-in will jump to `RPI-RP2` and the keyboard will never type. Clear that short, or release the key.

## Unrecognized or malfunctioned device

- Flash only a UF2 built for this keyboard (`merritt_merritt60ii_default.uf2`). A UF2 for another RP2040 board can enumerate as a broken device.
- Use the Pico's own micro-USB socket. Do not add a second USB connector in parallel.
- After a good flash the `RPI-RP2` drive ejects itself. If Windows says the device malfunctioned at that moment and Notepad then receives keystrokes, the flash worked.
- If Device Manager shows an unknown device and there is no `RPI-RP2` drive and no typing, try another cable and another port, then BOOTSEL and flash again.

Windows often lists a working keyboard only as "HID Keyboard Device". That name does not mean the product string failed. The firmware still reports manufacturer `Merritt Robotics Inc.` and product `RP2040 60-Key USB Keyboard II`.

## Reversed diodes

Symptom: one key, one row, or the whole matrix never types, and the diode check in `wiring-guide.md` shows the band on the column side.

The band is the cathode and it must face the row wire. `keyboard.json` is `COL2ROW`, which matches that direction. QMK drives each column low and reads the rows. A backwards diode does not conduct during that scan.

Fix the diode. Change `diode_direction` only if you reverse every diode and then rebuild. One reversed diode in a `COL2ROW` firmware image will not be fixed by a keymap edit.

## Incorrect GPIO mapping

Symptom: the wrong character appears, a whole row types the keys of another row, or a column is dead while its neighbor works.

Compare each wire with the table in `wiring-guide.md`. The silkscreen pin is what you solder. GP2 is pin 4, not pin 2. Pin 8, pin 13, pin 18, and pin 23 are ground. A column wire on a ground pin will not scan.

The firmware order is:

- Rows, top to bottom: GP2, GP3, GP4, GP5, GP6
- Columns, left to right: GP7, GP8, GP9, GP10, GP11, GP12, GP13, GP14, GP15, GP16, GP17, GP18

Those names are the `matrix_pins` arrays in `keyboard.json`. If you move a wire, change that array to the new pin, keep every pin unique, and rebuild. Do not leave the wire and the file disagreeing.

## Missing keypresses

Check the boring causes first:

- The key you wanted is on the Fn layer. F1 is Fn+1, not the `1` key alone. Arrows are Fn+H, Fn+J, Fn+K, and Fn+L.
- The switch pin is not actually soldered. Reheat that joint.
- That diode's band faces the column. See above.
- The row bus or column bus is broken between this key and the Pico. Continuity from the switch to the silkscreen pin should beep.
- Two wires of the same column were swapped left-to-right, so the key works but you are pressing a different column than you think. Use the matrix table.
- The editor lost focus. Click Notepad and try again.

A key that works alone but disappears only in some chords is not the usual open-circuit fault. Diodes are what make chords valid. A missing diode, or a diode replaced by a wire, can ghost or drop keys when several are held. Fit one 1N4148 per switch, band toward the row.

## Repeated keypresses

Two different things look similar:

- You are holding the key, and Windows repeats it. That is normal. The repeat rate is set in Windows keyboard settings. The firmware sends "this key is down" and later "this key is up". It does not send a stream of make codes for a held key.
- The letter appears twice, or chatters, from a light tap. That is contact bounce or a bad switch. This firmware uses QMK's `sym_defer_g` debounce at 5 ms (`"debounce": 5` and `"build": { "debounce_type": "sym_defer_g" }` in `keyboard.json`). If a particular switch still chatters, replace the switch. Raising `debounce` to 8 or 10 and rebuilding is the firmware-side change. Do not set it to 0.

A key that repeats forever is stuck closed: a bent pin, a solder bridge across the switch, or a keycap binding in the plate. Find it with the continuity check. If the stuck key is the top-left key, Bootmagic will enter the bootloader on every plug-in.

## Build errors

- `qmk: command not found` means the shell is not QMK MSYS, or `qmk setup` has not been run in this terminal.
- A missing keyboard name means the `merritt` folder is not at `~/qmk_firmware/keyboards/merritt/`.
- An error about `LAYOUT_ortho_5x12` means `keymap.c` and `keyboard.json` disagree about the number of keys. The layout macro takes 60 keycodes on each layer. Count them before rebuilding.

More symptoms and the intended wiring are in `wiring-guide.md`. The record of what was checked without a physical keyboard is `validation-report.md`.
