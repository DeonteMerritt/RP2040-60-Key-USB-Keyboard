# Build, flash, and test

This guide is for Windows. It builds the QMK firmware that turns the Raspberry Pi Pico into a USB keyboard, then copies the UF2 onto the Pico.

The keyboard types into whatever program is in front. You can type Seldun, Java, Python, JavaScript, C++, and other source code in an editor. Compiling and running those languages happens on the computer. The keyboard does not contain a compiler.

Hardware details are in `hardware-specification.md` and `wiring-guide.md`. The supported QMK revision is **0.34.6** (commit `d9f6dd215f2c4d295c6ad85b1f602125c2d81db1`). QMK's Windows instructions are at https://docs.qmk.fm/newbs_getting_started and the RP2040 flash steps are at https://docs.qmk.fm/flashing

## 1. Hardware and software you need

Hardware, from `bill-of-materials.csv`:

- One Raspberry Pi Pico (SC0915) or Pico H (SC0917)
- Sixty MX-style switches, sixty 1N4148 diodes, and wire, assembled as in `wiring-guide.md`
- A micro-USB cable that carries data. A charge-only cable will not flash and will not type.

Software:

- A 64-bit Windows 10 or Windows 11 PC
- QMK MSYS, the Windows build environment QMK publishes. The release current when this guide was written is **1.12.0**: https://github.com/qmk/qmk_distro_msys/releases/latest
- A text editor that saves plain text. Notepad can change one keycode. Visual Studio Code or Notepad++ is easier for the whole file.

You do not need PlatformIO. This project has no PlatformIO keyboard firmware.

## 2. Install QMK MSYS

1. Open https://github.com/qmk/qmk_distro_msys/releases/latest and download `QMK_MSYS.exe`.
2. Run the installer and accept the default location.
3. From the Start menu, open **QMK MSYS**. The window title and prompt should be the QMK MSYS terminal, not a purple "MSYS" prompt from a separate MSYS2 install.
4. In that window, run:

```
qmk setup
```

5. Answer `y` to the prompts. This clones QMK Firmware into `~/qmk_firmware` and installs the compiler inside QMK MSYS.

If you want this exact revision rather than whatever `master` is on the day you clone:

```
cd ~/qmk_firmware
git fetch --tags
git checkout 0.34.6
```

`0.34.6` was the tip of `master` on 30 September 2026. A newer master may still build this keyboard, because the definition uses `keyboard.json`. If a newer QMK rejects the file, check out `0.34.6` and build again.

## 3. WSL

WSL is not required. QMK's beginner path on Windows is QMK MSYS, and that is the path this guide uses.

Use WSL only if you have already chosen it. In Ubuntu on WSL2:

```
sudo apt update
sudo apt install -y git python3 python3-pip python3-venv gcc-arm-none-eabi binutils-arm-none-eabi libnewlib-arm-none-eabi
python3 -m venv ~/qmk-venv
source ~/qmk-venv/bin/activate
pip install qmk
qmk setup -H ~/qmk_firmware
```

Build the UF2 inside WSL, then copy the file to Windows, for example `/mnt/c/Users/your-name/Desktop/`. Flash it from Windows File Explorer. The `RPI-RP2` drive is a Windows USB disk. Do not depend on that drive appearing inside WSL.

## 4. Where to put the keyboard definition

The files that belong to this keyboard are:

`firmware/qmk/keyboards/merritt/merritt60ii/`

QMK looks them up as the keyboard name `merritt/merritt60ii`, which means this folder:

`~/qmk_firmware/keyboards/merritt/merritt60ii/`

In the QMK MSYS window, find the Windows path of the QMK tree:

```
cygpath -w ~/qmk_firmware
```

That path is often under `C:\QMK_MSYS\home\<your-name>\qmk_firmware`, not under `Documents`. Copy the whole `merritt` folder from this project into `keyboards`, so you end up with:

`qmk_firmware\keyboards\merritt\merritt60ii\keyboard.json`

From QMK MSYS, if the project is on drive C:

```
cp -a /c/path/to/rp2040-60-key-usb-keyboard-ii/firmware/qmk/keyboards/merritt ~/qmk_firmware/keyboards/
```

Replace `/c/path/to/` with the real folder. Check that the copy worked:

```
ls ~/qmk_firmware/keyboards/merritt/merritt60ii/keyboard.json
```

## 5. Build command

In QMK MSYS:

```
cd ~/qmk_firmware
qmk compile -kb merritt/merritt60ii -km default
```

A successful build ends with `[OK]` lines and leaves this file in the QMK tree:

```
~/qmk_firmware/merritt_merritt60ii_default.uf2
```

`cygpath -w ~/qmk_firmware/merritt_merritt60ii_default.uf2` prints the Windows path of that file.

The same build from `make`, if you are already in `~/qmk_firmware`, is:

```
make merritt/merritt60ii:default
```

Use the `qmk compile` command above if you are following this guide. It is the command QMK's current getting-started page uses.

## 6. Enter BOOTSEL mode

The first flash, and any flash after a bad firmware image, uses the button on the Pico.

1. Unplug the Pico.
2. Hold the white BOOTSEL button. It sits on the top of the Pico, near the micro-USB socket.
3. While holding BOOTSEL, plug the micro-USB cable into the Pico and into the computer.
4. Release BOOTSEL.
5. File Explorer shows a new drive named `RPI-RP2`.

A Pico that has never had firmware loaded can also appear as `RPI-RP2` the first time it is plugged in, without holding the button.

After this project's firmware is already running, you can enter the same drive without the button:

- Unplug the cable, hold the top-left key (the grave key), and plug the cable back in. That is Bootmagic on matrix `[0, 0]`.
- Or hold either Fn key and tap the top-left key. That key is `QK_BOOT` on the Fn layer.

## 7. Flash the UF2

1. Open the `RPI-RP2` drive in File Explorer.
2. Copy `merritt_merritt60ii_default.uf2` onto that drive.
3. The Pico reboots by itself. The `RPI-RP2` drive disappears. That is the flash completing, not a failed copy.

You can also run `qmk flash -kb merritt/merritt60ii -km default` from QMK MSYS after the drive is mounted. Copying the UF2 in File Explorer is the method to use if the command cannot see the drive.

## 8. Reconnect and test

1. If the drive disappeared, the keyboard is already reconnected. If you unplugged it, plug it back in without holding BOOTSEL and without holding the top-left key.
2. Windows may call it a HID keyboard device. The USB strings in the firmware are manufacturer `Merritt Robotics Inc.` and product `RP2040 60-Key USB Keyboard II`. Device Manager does not always show the product string in the device name. Open the device details if you want to confirm the string. Either way, the test below is whether it types.
3. Open Notepad.
4. Type `hello`. You should see those letters.
5. Hold Shift and press `1`. You should see `!`.
6. Hold Ctrl and press `A`. Notepad selects all of the text. That checks a modifier chord.
7. Hold Fn and press `H`, then `J`, `K`, and `L`. The cursor moves left, down, up, and right.
8. Hold Fn and press `1`. That is F1.
9. Walk the matrix table in `key-layout.md` and press each of the 60 keys once.

If a key does nothing, go to `troubleshooting.md` before changing the keymap. A wiring fault looks the same as a wrong keycode.

## 9. Change a key and rebuild

The file to edit inside the QMK tree is:

`keyboards/merritt/merritt60ii/keymaps/default/keymap.c`

Example: the base-layer key to the right of P sends backslash (`KC_BSLS`). To make that key send minus instead, change that one token from `KC_BSLS` to `KC_MINS`. Save the file as plain text.

Build and flash again:

```
cd ~/qmk_firmware
qmk compile -kb merritt/merritt60ii -km default
```

Put the Pico in BOOTSEL mode, or use Fn plus the top-left key, and copy the new UF2 onto `RPI-RP2`.

Keycodes are listed at https://docs.qmk.fm/keycodes

If you keep this project's `hardware/design.json` as the written specification, change the matching `base_code` there too, then run:

```
python tools/validate_design.py
```

from the `rp2040-60-key-usb-keyboard-ii` folder. QMK itself only compiles `keymap.c`. The validator is what checks that the specification, the keymap, and the docs still describe the same keyboard.

Changing a keycode does not change a wire. Changing a wire requires the same change in `keyboard.json` `matrix_pins` and in the wiring tables, then a rebuild.
