# Schematic specification

This is the electrical specification of the hand-wired Raspberry Pi Pico keyboard. It matches `hardware/design.json`, `hardware/netlist.csv`, and the QMK matrix.

An editable KiCad 7 schematic of the same nets is `hardware/kicad/merritt60ii.kicad_sch`. That drawing is source for review and for a later layout. It is not a manufacturing release. There is no routed PCB in this project, and the installed KiCad 7.0.11 command-line tool has no electrical-rule or design-rule command.

## What the drawing is

- Reference U1 is a Raspberry Pi Pico module (SC0915 or the headered Pico H, SC0917), drawn as a 40-pin module.
- SW1–SW60 are the key switches.
- D1–D60 are 1N4148 diodes. Symbol pin 1 is the cathode (the band). Symbol pin 2 is the anode.
- The micro-USB connector, flash, crystal, and regulator stay inside the Pico. They are not separate parts on this schematic.
- The bare RP2040 QFN is not the controller on this drawing.

## Switch and diode

For key number `n` from 1 to 60, with row `r = (n - 1) // 12` and column `c = (n - 1) % 12`:

| Pin | Net |
| --- | --- |
| SWn pin 1 | `COLc` |
| SWn pin 2 | `Kn` |
| Dn pin 2 (anode, no band) | `Kn` |
| Dn pin 1 (cathode, band) | `ROWr` |

U1 joins every `ROWr` and `COLc`:

| Net | Pico GPIO | Silkscreen pin | U1 pin on this symbol |
| --- | --- | --- | --- |
| ROW0 | GP2 | 4 | 4 |
| ROW1 | GP3 | 5 | 5 |
| ROW2 | GP4 | 6 | 6 |
| ROW3 | GP5 | 7 | 7 |
| ROW4 | GP6 | 9 | 9 |
| COL0 | GP7 | 10 | 10 |
| COL1 | GP8 | 11 | 11 |
| COL2 | GP9 | 12 | 12 |
| COL3 | GP10 | 14 | 14 |
| COL4 | GP11 | 15 | 15 |
| COL5 | GP12 | 16 | 16 |
| COL6 | GP13 | 17 | 17 |
| COL7 | GP14 | 19 | 19 |
| COL8 | GP15 | 20 | 20 |
| COL9 | GP16 | 21 | 21 |
| COL10 | GP17 | 22 | 22 |
| COL11 | GP18 | 24 | 24 |

No other U1 pin is on a matrix net. Ground, 3V3, VBUS, and VSYS are not matrix nets. The matrix return path is the column pin that the firmware drives low.

`hardware/netlist.csv` lists the same connections, one row per pin.

## Scan, restated for the drawing

`COL2ROW` in the firmware means the cathode net is the row. During a scan the selected `COLc` pin is low, each `ROWr` pin is an input with a pull-up, and a closed switch forward-biases Dn from `ROWr` toward `COLc`.

## Checks that were possible here

KiCad 7.0.11 provides `kicad-cli sch export netlist`. It does not provide `kicad-cli sch erc` or `kicad-cli pcb drc`. Those subcommands are not in this version. The project validator exports the netlist when KiCad is available and checks that:

- There are 60 switches and 60 diodes.
- Each diode cathode pin is on the row net for its key.
- Each diode anode and the matching switch pin share a private net.
- Each column net touches only that column's switches and the one Pico pin in the table above.
- Row nets and column nets are not tied together.

That is a connectivity check of the schematic source. It is not a KiCad ERC report, and it is not a physical board test.

## Remaining CAD work

Do not send these files to a board house.

Still undone, and required before any fabricated PCB:

1. A future bare-RP2040 board is a different design. It needs the RP2040, a 12 MHz crystal and load capacitors, a W25Q16JV or another flash part QMK's second-stage bootloader supports, a 3.3 V regulator, a USB connector with series resistors on D+ and D−, a BOOTSEL button, a reset strategy, and decoupling, following Raspberry Pi's hardware design guide. This repository does not contain that design.
2. The installed KiCad libraries include a bare RP2040 symbol and Cherry MX footprints. They do not include a verified Raspberry Pi Pico module footprint. A carrier PCB for the Pico module would need that footprint checked against the Pico mechanical drawing before use.
3. Install KiCad 8 or newer so schematic ERC and PCB DRC can be run from `kicad-cli`.
4. Assign footprints, route the board, run DRC, and review Gerbers. None of those steps is done here.
5. The hand-wired build does not need that PCB. Build it from `wiring-guide.md`.
