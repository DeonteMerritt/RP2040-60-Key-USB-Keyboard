# Hardware specification

RP2040 60-Key USB Keyboard II, for Deonte Lamar Merritt, Merritt Robotics Inc.

This version is a module design. The controller is a complete Raspberry Pi Pico board. The switches are hand-wired to its header pins. The keyboard uses the Pico's built-in micro-USB connector. It is not a custom PCB with a bare RP2040.

## Controller

| Item | Value |
| --- | --- |
| Board | Raspberry Pi Pico, order code SC0915 |
| Assembly alternate | Raspberry Pi Pico H, order code SC0917 (same circuit, headers already fitted) |
| MCU | Raspberry Pi RP2040, dual Cortex-M0+ |
| Flash on the module | Winbond W25Q16JV, 2 MB |
| Crystal on the module | Abracon ABM8-272-T3, already fitted on the Pico |
| USB | Micro-USB B receptacle on the Pico, USB device |
| User GPIO on the header | GP0–GP22 and GP26–GP28 (26 pins) |
| QMK board target | `GENERIC_RP_RP2040` |
| QMK processor | `RP2040` |
| QMK bootloader | `rp2040` (UF2 mass storage) |

Pico H is electrically the same product with a pre-soldered 40-pin header. Use it if you do not want to solder headers onto SC0915. Do not substitute a Raspberry Pi Pico 2. That board uses an RP2350, not an RP2040. Do not substitute a Pico W for this reference. This design does not use wireless hardware.

Official source for the board, the flash part, the BOOTSEL procedure, and the statement that GPIO power is 3.3 V: Raspberry Pi Pico Datasheet, https://datasheets.raspberrypi.com/pico/pico-datasheet.pdf

QMK names RP2040 pins `GP0`, `GP1`, and so on. Those numbers are the RP2040 GPIO numbers. They are not the 1–40 numbers printed on the Pico. QMK documents this in https://docs.qmk.fm/platformdev_rp2040

## Why these GPIO pins

The matrix uses 5 row pins and 12 column pins. Every one of them is broken out on the Pico header, is a bidirectional digital GPIO, and has an internal pull-up.

| Signal | GPIO | Silkscreen pin | Side, USB at the top |
| --- | --- | --- | --- |
| ROW0 | GP2 | 4 | Left |
| ROW1 | GP3 | 5 | Left |
| ROW2 | GP4 | 6 | Left |
| ROW3 | GP5 | 7 | Left |
| ROW4 | GP6 | 9 | Left |
| COL0 | GP7 | 10 | Left |
| COL1 | GP8 | 11 | Left |
| COL2 | GP9 | 12 | Left |
| COL3 | GP10 | 14 | Left |
| COL4 | GP11 | 15 | Left |
| COL5 | GP12 | 16 | Left |
| COL6 | GP13 | 17 | Left |
| COL7 | GP14 | 19 | Left |
| COL8 | GP15 | 20 | Left, bottom |
| COL9 | GP16 | 21 | Right, bottom |
| COL10 | GP17 | 22 | Right |
| COL11 | GP18 | 24 | Right |

Pins 8, 13, 18, and 23 are ground. The matrix skips them. No matrix wire lands on ground, 3.3 V, VBUS, or VSYS.

These pins are not used, and must not be used for the matrix:

| GPIO | Reason |
| --- | --- |
| GP23 | On-board switch-mode power supply control. The Pico datasheet says not to use it. It is not on the header. |
| GP24 | VBUS sense. Not on the header. |
| GP25 | User LED. Not on the header. |
| GP29 | Measures VSYS/3. Not on the header. |
| USB D+ and D− | Dedicated USB pins, wired on the Pico to the micro-USB connector through 27 ohm resistors. They are not matrix GPIO. |

GP0 and GP1 (pins 1 and 2) are free. This firmware does not use them. GP19–GP22 and GP26–GP28 are also free.

QMK warns that RP2040 GPIO is not 5 V tolerant. This matrix does not apply 5 V to any GPIO. The only current in a closed switch is the Pico's internal pull-up, on the order of a few tens of microamps per pressed key. That is inside the GPIO sink rating, so the hand-wired build does not add series resistors. A future PCB may add them as protection. If it does, the firmware scan direction does not change.

The seventeen matrix GPIOs are all different. None of them is an ADC-only pin. GP26–GP28 can be digital GPIO, but this design leaves them unused.

## Matrix

| Item | Value |
| --- | --- |
| Physical keys | 60 |
| Electrical matrix | 5 rows by 12 columns, every position populated |
| Arrangement | Ortholinear. Row 0 is the top edge. Column 0 is the left edge. |
| Pitch | 19.05 mm (0.75 inch) in both directions |
| Diode | One 1N4148 per switch |
| Firmware diode direction | `COL2ROW` |
| Debounce | 5 ms, QMK algorithm `sym_defer_g` |
| Pressed electrical level | Logic 0 (`input_pressed_state` 0, the QMK default) |

### Diode orientation

The band printed on the 1N4148 is the cathode.

- Cathode (band) connects to the row wire, and that row wire connects to the row GPIO.
- Anode (the end without the band) connects to one pin of the switch.
- The other switch pin connects to the column wire, and that column wire connects to the column GPIO.

Conventional current, when the switch is closed and the column is driven low, flows from the row pull-up, through the diode toward the band, through the switch, and into the column pin. QMK's name for that orientation is `COL2ROW`: the diode points from the column side toward the row side. The black band faces the row.

`keyboard.json` sets `"diode_direction": "COL2ROW"`. Do not change that setting unless you reverse every diode.

### Scan

QMK's built-in matrix scanner does this for `COL2ROW`:

1. Row pins are inputs with internal pull-ups, so an open switch reads as 1.
2. Column pins rest as inputs (high impedance).
3. For each column, the firmware drives that column low, waits the matrix I/O delay (QMK's default, 30 microseconds; this keyboard does not override it), and reads all five row pins.
4. A row that reads 0 is a closed switch at that row and column. The diode is forward from the row toward the column.
5. The column is returned to high impedance, and the next column is scanned.
6. `sym_defer_g` reports a change only after the raw reading has stayed the same for 5 ms. That rejects contact bounce.

The scanner then updates a USB HID keyboard report. It does not print switch state on a serial port. See the firmware section below.

Diodes stop ghosting. Pressing three corners of a rectangle cannot invent a fourth key, so chords and modifier combinations are valid at the same time.

## USB identity

| Field | Value |
| --- | --- |
| Vendor ID | `0xFEED` |
| Product ID | `0x4D60` |
| Manufacturer string | Merritt Robotics Inc. |
| Product string | RP2040 60-Key USB Keyboard II |
| Device version | 0.2.0 |
| Reported maximum power | 500 mA |
| Connector | The Pico's built-in micro-USB receptacle |

`0xFEED` is the vendor ID QMK's own new-keyboard template uses for a personal project. `0x4D60` was not used with that vendor ID anywhere in the QMK 0.34.6 keyboard tree when this ID was chosen. It is not a USB-IF assignment. Do not ship a commercial product with this ID.

Power comes from the USB host through the Pico's micro-USB connector. The Pico's on-board regulator makes 3.3 V for the RP2040. The switch matrix does not connect to 3.3 V or to ground.

## This module versus a future bare-RP2040 PCB

This version:

- Uses a Raspberry Pi Pico or Pico H module.
- Uses that module's flash, crystal, regulator, BOOTSEL button, and micro-USB connector.
- Hand-wires the 60 switches and 60 diodes to header pins.

A future custom PCB, which is not designed here and is not ready to manufacture, would replace the module with a bare RP2040 and its own supporting parts: crystal, flash, 3.3 V regulator, USB connector, series resistors on D+ and D−, BOOTSEL and reset buttons, and decoupling. That board would be a different schematic. The KiCad library installed with this project contains a bare RP2040 symbol. That symbol is the wrong part for this version, and it is not used.

## Firmware that matches this hardware

QMK Firmware 0.34.6, keyboard `merritt/merritt60ii`.

- Real USB HID keyboard reports, including modifiers and NKRO.
- Matrix scan, 5 ms `sym_defer_g` debounce, and the keymap in `keymaps/default/keymap.c`.
- Bootmagic on matrix position `[0, 0]`, the top-left key.
- `QK_BOOT` on the Fn layer at that same key.

There is no PlatformIO firmware in this project. An empty repository was inspected before this design was written, and it contained no PlatformIO sketch. A serial-only switch dump is not included, and it would not be USB keyboard firmware.

The keyboard types characters into the focused program on the computer. That includes source code in Seldun, Java, Python, JavaScript, C++, and other languages. Compiling and running those languages is done by the computer's toolchain, not by the keyboard.
