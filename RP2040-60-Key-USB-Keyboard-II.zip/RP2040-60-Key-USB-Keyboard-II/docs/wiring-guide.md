# Wiring and assembly

This is the hand-wired Raspberry Pi Pico build. Row 0 is the top edge of the keyboard, the edge farthest from you while typing. Column 0 is the left edge. The Pico's USB connector is the micro-USB socket already on the board. Do not add a second USB connector.

Read `hardware-specification.md` for the electrical rules. The per-key table, with legend, keycode, GPIO, and silkscreen pin, is in `key-layout.md`.

## Tools

- Soldering iron and electronics solder
- Side cutters
- A multimeter with a continuity or diode mode
- The Pico, 60 switches, 60 1N4148 diodes, wire, and a data-capable micro-USB cable from the bill of materials

## GPIO wiring table

Wire each signal to the silkscreen pin, not to the GPIO number. GP2 is pin 4. It is not pin 2.

| Signal | GPIO | Silkscreen pin | Connect to |
| --- | --- | --- | --- |
| ROW0 | GP2 | 4 | Cathode bus of the top key row |
| ROW1 | GP3 | 5 | Cathode bus of the second row |
| ROW2 | GP4 | 6 | Cathode bus of the third row |
| ROW3 | GP5 | 7 | Cathode bus of the fourth row |
| ROW4 | GP6 | 9 | Cathode bus of the bottom row |
| COL0 | GP7 | 10 | Free switch pin of the leftmost column |
| COL1 | GP8 | 11 | Column 1 |
| COL2 | GP9 | 12 | Column 2 |
| COL3 | GP10 | 14 | Column 3 |
| COL4 | GP11 | 15 | Column 4 |
| COL5 | GP12 | 16 | Column 5 |
| COL6 | GP13 | 17 | Column 6 |
| COL7 | GP14 | 19 | Column 7 |
| COL8 | GP15 | 20 | Column 8 |
| COL9 | GP16 | 21 | Column 9 |
| COL10 | GP17 | 22 | Column 10 |
| COL11 | GP18 | 24 | Rightmost column |

With the USB connector at the top of the Pico:

- Pins 1 through 20 run down the left edge. Pin 1 is GP0, next to the USB connector. Rows start at pin 4. Columns 0 through 8 continue down that same edge. Skip every pin marked GND (pins 3, 8, 13, and 18).
- Pins 21 through 40 run up the right edge if you count from the bottom, or down from pin 40 at the USB end. Column 9 is pin 21 (GP16), at the bottom. Column 10 is pin 22 (GP17). Pin 23 is GND. Column 11 is pin 24 (GP18).

Do not connect any row or column to GND, AGND, 3V3, 3V3_EN, VSYS, VBUS, RUN, or ADC_VREF.

## Diode direction

On every switch:

1. The two metal pins of an MX-style switch are electrically the same. Pick one side and use that same side for the diode on all 60 switches.
2. Solder the diode anode, the end without the band, to that switch pin.
3. The banded end is the cathode. It joins the row bus.
4. The unused switch pin joins the column bus.

```
column GPIO ---- switch ---- anode of 1N4148 ----|>|---- band (cathode) ---- row GPIO
```

The firmware setting that matches this drawing is `COL2ROW`. QMK drives the column low and reads the row. A press pulls the row to logic 0 through the diode.

If the band faces the column instead of the row, that key will not register. Fix the diode. Do not flip `diode_direction` for a single key.

## Assembly order

1. If you have a Pico without headers (SC0915), solder a 1×20 pin header into each long edge. A Pico H (SC0917) already has them. Check that no two adjacent pins are bridged.
2. Mount the 60 switches in a 5×12 grid, 19.05 mm apart, or in a 5×12 MX plate. Column 0 is on the left. Row 0 is the top. Orient every switch the same way.
3. On each switch, solder a 1N4148 anode to the chosen switch pin. Keep the band pointing toward the row bus, across the row, not down the column.
4. Run one insulated or bare bus along each row and solder every cathode in that row to it. You will have five row buses.
5. Run one bus down each column and solder the free switch pin of each switch in that column to it. You will have twelve column buses.
6. Insulate row wires wherever they cross column wires. A row must never touch a column except through a switch and its diode.
7. Solder the five row buses to Pico pins 4, 5, 6, 7, and 9 (GP2 through GP6).
8. Solder the twelve column buses to Pico pins 10, 11, 12, 14, 15, 16, 17, 19, 20, 21, 22, and 24, in that left-to-right order.
9. Leave the Pico's micro-USB socket clear so the cable can plug in. The cable is the only USB connection.

## Checks before plugging into a computer

With the Pico unpowered:

- Continuity: each row bus reaches only its own Pico pin. ROW0 reaches pin 4 and does not reach pin 5.
- Continuity: each column bus reaches only its own Pico pin.
- No row bus is continuous with any column bus while every switch is released.
- Diode mode: with the red probe on a column pin and the black probe on the row pin of the same key, you should see a diode drop only while that switch is held. If you see the drop with the probes swapped, that diode is backwards.
- No matrix wire is continuous with pin 36 (3V3) or with any GND pin.

Then flash the firmware using `build-flash-test-guide.md` before expecting the Pico to type. A new Pico enumerates as the `RPI-RP2` drive until firmware is copied onto it. That drive is the bootloader, not a broken keyboard.

## One key, as a reference

SW1 is the top-left key. It types grave (`` ` ``) on the base layer.

| Part | Connection |
| --- | --- |
| D1 cathode (band) | ROW0, Pico pin 4, GP2 |
| D1 anode | One pin of SW1 |
| Other pin of SW1 | COL0, Pico pin 10, GP7 |

SW60 is the bottom-right key. It types Right Shift on the base layer. Its diode cathode is ROW4 (pin 9, GP6). Its column is COL11 (pin 24, GP18). The same pattern, with the row and column from `key-layout.md`, covers SW2 through SW59.
