# Default keymap

`keymap.c` is the file QMK compiles for this keyboard.

* Layer `_BASE` is the typing layer.
* Layer `_FN` is momentary. Hold either key marked Fn.
* `_______` means the base-layer key remains active while Fn is held.
* `QK_BOOT` on Fn + the top-left key reboots into the UF2 bootloader.

To change one key, replace that keycode, then run:

    qmk compile -kb merritt/merritt60ii -km default

Flash the new UF2. The hardware pins do not change when only a keycode changes.
