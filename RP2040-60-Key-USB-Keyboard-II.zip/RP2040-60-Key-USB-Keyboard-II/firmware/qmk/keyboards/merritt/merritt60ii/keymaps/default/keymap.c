// Copyright 2026 Deonte Lamar Merritt
// SPDX-License-Identifier: GPL-2.0-or-later
//
// Default keymap for the RP2040 60-Key USB Keyboard II.
// This file is compiled into QMK. QMK sends USB HID keyboard reports.
// Change a key by replacing the keycode below, then rebuild and flash.
// See docs/build-flash-test-guide.md.

#include QMK_KEYBOARD_H

enum layer_names {
    _BASE = 0,
    _FN,
};

const uint16_t PROGMEM keymaps[][MATRIX_ROWS][MATRIX_COLS] = {
    // Physical top row is matrix row 0. Column 0 is the left edge.
    // Hold either Fn key (MO) for the function layer.
    [_BASE] = LAYOUT_ortho_5x12(
    KC_GRV    , KC_1      , KC_2      , KC_3      , KC_4      , KC_5      , KC_6      , KC_7      , KC_8      , KC_9      , KC_0      , KC_BSPC   ,
    KC_TAB    , KC_Q      , KC_W      , KC_E      , KC_R      , KC_T      , KC_Y      , KC_U      , KC_I      , KC_O      , KC_P      , KC_BSLS   ,
    KC_ESC    , KC_A      , KC_S      , KC_D      , KC_F      , KC_G      , KC_H      , KC_J      , KC_K      , KC_L      , KC_SCLN   , KC_QUOT   ,
    KC_LSFT   , KC_Z      , KC_X      , KC_C      , KC_V      , KC_B      , KC_N      , KC_M      , KC_COMM   , KC_DOT    , KC_SLSH   , KC_ENT    ,
    KC_LCTL   , KC_LGUI   , KC_LALT   , MO(_FN)   , KC_LBRC   , KC_RBRC   , KC_SPC    , KC_MINS   , KC_EQL    , MO(_FN)   , KC_DEL    , KC_RSFT   
    ),
    // Transparent keys (_______) keep the base key while Fn is held.
    // Fn + top-left key (grave position) is QK_BOOT.
    [_FN] = LAYOUT_ortho_5x12(
    QK_BOOT   , KC_F1     , KC_F2     , KC_F3     , KC_F4     , KC_F5     , KC_F6     , KC_F7     , KC_F8     , KC_F9     , KC_F10    , KC_DEL    ,
    KC_F11    , KC_F12    , KC_PSCR   , KC_SCRL   , KC_PAUS   , _______   , KC_HOME   , KC_PGDN   , KC_PGUP   , KC_END    , KC_INS    , _______   ,
    _______   , _______   , _______   , _______   , _______   , _______   , KC_LEFT   , KC_DOWN   , KC_UP     , KC_RGHT   , _______   , _______   ,
    _______   , _______   , _______   , _______   , _______   , _______   , _______   , _______   , KC_MUTE   , KC_VOLD   , KC_VOLU   , _______   ,
    _______   , _______   , _______   , _______   , _______   , _______   , _______   , _______   , _______   , _______   , KC_PGUP   , KC_PGDN   
    ),
};
