merritt_merritt60ii_default.uf2

Compiled with QMK Firmware 0.34.6 (commit d9f6dd215f2c4d295c6ad85b1f602125c2d81db1).
Command: qmk compile -kb merritt/merritt60ii -km default

Flash: hold BOOTSEL on the Raspberry Pi Pico while plugging in the micro-USB cable, then copy this UF2 onto the RPI-RP2 drive.

This file was produced by a software build. It was not flashed to a Pico, and the keyboard was not tested on hardware.
