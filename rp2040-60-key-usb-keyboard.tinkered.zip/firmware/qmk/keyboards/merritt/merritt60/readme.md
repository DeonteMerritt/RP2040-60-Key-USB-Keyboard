# Merritt Custom Keyboard (merritt60)

RP2040-based 60% ANSI (GH60-style) keyboard target for QMK.

## Matrix
- 5 rows x 14 cols
- Diode direction: COL2ROW

## Pin mapping
- Rows: GP0, GP1, GP2, GP3, GP4
- Cols: GP6..GP19

## Build
Run from your `qmk_firmware` root after placing this keyboard folder under `keyboards/merritt/merritt60`:

```bash
qmk compile -kb merritt/merritt60 -km default
```

## Flash (RP2040 UF2)
1. Hold BOOT, tap RESET (or connect USB while BOOT is held)
2. Flash with QMK CLI:

```bash
qmk flash -kb merritt/merritt60 -km default
```

Or copy the generated UF2 to the RP2040 boot drive manually.

## Notes
- This scaffold is provided as a starting point and must be validated against your final schematic/PCB pinout.
- See `docs/merritt-custom-keyboard-spec.md` and `docs/merritt-build-flash-test-guide.md`.
