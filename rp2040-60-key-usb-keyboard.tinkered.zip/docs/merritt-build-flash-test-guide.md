# Merritt Custom Keyboard — Beginner Build, Flash, and Test Guide

## 1) What is ready vs what still needs CAD verification

Ready in this project:
- Electrical design specification
- RP2040 + USB-C + matrix architecture
- QMK firmware scaffold and keymap

Still required before fabrication in KiCad:
- Final schematic capture in `.kicad_sch`
- Full PCB placement/routing in `.kicad_pcb`
- ERC/DRC run and all blocking errors resolved
- Gerber + drill generation from KiCad Plot/Drill tools

Untested/unverified flags:
- Firmware compile is not executed in this environment for QMK RP2040 toolchain
- Exact footprint clearances (hot-swap sockets vs diode bodies) require KiCad footprint/3D validation
- GH60 mounting coordinates must be confirmed against your exact case vendor drawing

## 2) Suggested beginner assembly strategy (mixed)

Because you selected mixed beginner-friendly assembly:
- Keep tactile buttons (BOOT/RESET) as easy hand-solder parts
- Keep USB-C, RP2040, flash, and regulator as SMD (required/practical)
- For matrix diodes, prefer SMD to avoid hot-swap socket interference; through-hole diodes are possible only after strict clearance checks

Assembly order (recommended):
1. Solder smallest SMD passives first (resistors/capacitors)
2. Solder RP2040, flash, regulator, crystal, ESD and protection parts
3. Solder USB-C connector carefully (mechanical tabs first)
4. Solder BOOT and RESET buttons
5. Solder hot-swap sockets
6. Solder matrix diodes
7. Solder optional LED and headers
8. Clean flux, inspect joints under magnification
9. Do power-only smoke test before inserting switches
10. Install switches and stabilizers last

## 3) Stabilizer and switch fit notes

Large keys requiring stabilizer support in your selected layout:
- Backspace 2U
- Enter 2.25U
- Left Shift 2.25U
- Right Shift 2.75U
- Spacebar 6.25U

Practical check in KiCad:
- Import trusted MX + Kailh socket + stabilizer footprints from known keyboard libraries
- Use 3D viewer to ensure no collision between diode locations and socket underside geometry
- Lock keepout circles around all GH60 mounting holes before final routing

## 4) KiCad implementation workflow (schematic -> PCB -> fab)

## A) Schematic capture
1. Create project `merritt-custom-keyboard` in KiCad 8.
2. Place symbols for:
   - RP2040
   - QSPI flash
   - 12 MHz crystal and load caps
   - 3.3V regulator
   - USB-C receptacle (USB2.0)
   - CC resistors (5.1k), polyfuse, TVS, USB ESD array
   - 61 switches, 61 diodes, boot/reset buttons
3. Assign net labels exactly as in the spec (`ROW0..ROW4`, `COL0..COL13`, USB nets).
4. Annotate and assign footprints.
5. Run ERC; resolve all errors.

## B) PCB setup
1. Set board outline to GH60 target: 285.75 mm × 95.25 mm.
2. Import netlist/update PCB from schematic.
3. Place USB-C and MCU section first, then matrix blocks.
4. Add mounting holes from GH60 case template and keepout zones.
5. Route USB differential pair first, then power, then matrix.
6. Add GND plane on one or both layers with via stitching.
7. Add silkscreen labels, polarity marks, and revision text.
8. Run DRC; resolve all blocking violations.

## C) Pre-manufacturing checks
- Check annular ring and drill sizes against fab limits
- Confirm minimum track/space and soldermask clearance
- Re-run DRC after every major tweak
- Verify polarity orientation for all 61 diodes
- Verify BOOT/RESET accessibility with case installed

## D) Manufacturing file export (KiCad)
1. `PCB Editor -> File -> Plot...`
2. Generate Gerbers (at minimum):
   - F.Cu, B.Cu
   - F.Mask, B.Mask
   - F.SilkS, B.SilkS
   - Edge.Cuts
3. `Generate Drill Files...` (Excellon)
4. Zip Gerbers + drill files + fabrication notes
5. Optionally generate position files/BOM for assembly service

## 5) Firmware build and flash (QMK)

Source location in this project:
- `firmware/qmk/keyboards/merritt/merritt60/`

Prerequisites on your computer:
- QMK CLI installed
- QMK firmware repo initialized
- ARM GCC toolchain from QMK setup

Build:
1. Copy `firmware/qmk/keyboards/merritt/merritt60` into your local `qmk_firmware/keyboards/merritt/` path.
2. Run:
   - `qmk compile -kb merritt/merritt60 -km default`

Flash (UF2 workflow on RP2040):
1. Hold BOOT, tap RESET (or plug in while holding BOOT if wired that way).
2. Board appears as a USB mass storage boot drive.
3. Run:
   - `qmk flash -kb merritt/merritt60 -km default`
   - or copy generated `.uf2` to the boot drive manually.

## 6) Bring-up and keyboard testing

Power bring-up sequence:
1. Plug USB with no switches installed first.
2. Verify 5V on VBUS rail and 3.3V regulator output.
3. Confirm no overheating of RP2040/regulator.
4. Enter boot mode and confirm UF2 drive appears.

Functional testing:
1. Flash firmware.
2. Open a key tester (web or OS utility).
3. Insert and test switches row by row.
4. Verify no ghosting with multi-key presses.
5. Validate Fn layer keys (F-row and boot key behavior).

If key scan errors appear:
- Re-check diode orientation (stripe toward row)
- Re-check matrix row/column net labels
- Confirm QMK matrix pin mapping matches schematic

## 7) Unresolved issues to close before first fabrication order

Mandatory closeout list:
1. Validate hot-swap socket + diode footprint clearance on all key positions in KiCad 3D.
2. Validate GH60 mounting coordinates and USB cutout alignment for your specific case.
3. Run and pass KiCad ERC and DRC with zero blocking errors.
4. Build firmware once with local QMK CLI and confirm successful compile output.

Do not submit to fabrication until all four are complete.
