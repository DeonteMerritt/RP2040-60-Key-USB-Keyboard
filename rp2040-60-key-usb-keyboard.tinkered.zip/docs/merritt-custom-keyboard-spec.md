# Merritt Custom Keyboard — Hardware Design Specification

Status: Draft implementation package for external PCB CAD completion (KiCad)

## 1) Locked project choices

- Layout: ANSI 60% (61 keys), GH60-style
- Switch format: Cherry MX compatible, hot-swap (Kailh-style sockets)
- PCB outline target: GH60-compatible, 285.75 mm × 95.25 mm
- Assembly style: Mixed beginner-friendly
- MCU: RP2040 (native USB device/HID capable)
- PCB stack-up target: 2-layer FR-4, 1.6 mm, 1 oz copper

## 2) Platform limits (important)

What this package includes:
- Complete electrical architecture and schematic connection details
- Matrix + diode polarity plan
- RP2040 pin map
- BOM (starter production list)
- Firmware scaffold and keymap (QMK)
- Step-by-step KiCad layout and manufacturing export instructions

What is not directly generated/validated in this environment:
- Native interactive KiCad PCB routing and automatic DRC execution
- Final Gerber/drill generation output files
- Physical SI/EMI/ESD compliance testing

Therefore, this package is implementation-ready but must be completed and verified in KiCad before fabrication.

## 3) Keyboard matrix and diode plan

## Matrix dimensions
- Rows: 5
- Columns: 14
- Capacity: 70 positions (61 populated, remaining positions unstuffed for standard ANSI 60%)

## Diode orientation (ghosting prevention)
- One diode per key switch, in series with each switch path
- QMK diode direction: `COL2ROW`
- Physical polarity rule for each key diode:
  - Anode -> column net side
  - Cathode (striped end) -> row net side

Marking guidance on PCB silkscreen:
- Print diode designators as `D1..D61`
- Add local polarity marker: stripe symbol toward row side
- Add one global note near matrix: `Diodes: stripe to ROW (COL2ROW)`

## 4) RP2040 pin map (proposed)

## Matrix GPIO assignment
Rows:
- ROW0 -> GP0
- ROW1 -> GP1
- ROW2 -> GP2
- ROW3 -> GP3
- ROW4 -> GP4

Columns:
- COL0  -> GP6
- COL1  -> GP7
- COL2  -> GP8
- COL3  -> GP9
- COL4  -> GP10
- COL5  -> GP11
- COL6  -> GP12
- COL7  -> GP13
- COL8  -> GP14
- COL9  -> GP15
- COL10 -> GP16
- COL11 -> GP17
- COL12 -> GP18
- COL13 -> GP19

## Other functions
- Reset pushbutton: RUN pin to GND (momentary)
- BOOT pushbutton: QSPI_CS (BOOTSEL function) to GND (momentary)
- Optional status LED: GP25 -> LED -> resistor -> GND

Reserved/not used for matrix:
- USB D+/D- are dedicated USB pins on RP2040 package (not GPIO matrix pins)
- Avoid using QSPI flash pins for general matrix I/O

## 5) Schematic connection details

## RP2040 minimum support circuitry
1. Power domains
   - USB VBUS (5V) -> polyfuse (500 mA hold typical) -> +5V board rail
   - +5V rail -> LDO 3.3V regulator (example: AP2112K-3.3 or equivalent)
   - 3.3V rail -> RP2040 3V3 pins + flash + pull-ups

2. Decoupling (place close to RP2040 pins)
   - 100 nF per VDD pin (multiple capacitors)
   - 1 uF bulk near RP2040
   - 10 uF bulk on 3.3V rail near regulator output
   - 1 uF/10 uF on regulator input per regulator datasheet

3. Clock
   - 12 MHz crystal connected to XIN/XOUT
   - 2x load capacitors (typically 18-27 pF; select per crystal CL)

4. External flash (required)
   - 3.3V QSPI NOR flash (example: W25Q128JV, 16 MB)
   - Connect QSPI lines per RP2040 hardware design guide
   - Pull-up on QSPI_CS per reference design if required by chosen flash/vendor app note

5. Reset/boot controls
   - RUN pin pull-up to 3.3V (typ. 100k)
   - Reset button from RUN to GND
   - BOOT button from QSPI_CS/BOOTSEL net to GND

## USB-C device-side circuitry
1. Connector
   - USB Type-C receptacle (USB2.0 only footprint)

2. Configuration channel resistors (required)
   - CC1 -> 5.1k -> GND
   - CC2 -> 5.1k -> GND
   - Advertises default USB device sink behavior

3. USB data routing/protection
   - D+ and D- from connector -> low-capacitance USB ESD protection array -> RP2040 USB_DP/USB_DM
   - Add optional 22 ohm series resistors on D+/D- near RP2040 if recommended by layout and signal tuning

4. VBUS protection/power entry
   - VBUS -> resettable fuse (polyfuse)
   - TVS diode on VBUS to GND (ESD/transient clamp)
   - Optional ferrite bead filtering between connector VBUS and local 5V rail depending on EMC goals

5. Shield/ground strategy
   - USB-C shell tied to board GND, either direct or through RC/ferrite strategy per EMC preference

## Key matrix wiring
Per key (Kx):
- Column net -> switch -> diode anode
- Diode cathode -> row net
- Net current path when pressed: COL -> SW -> DIODE -> ROW

## Stabilizer mounting features
For GH60 ANSI large keys include stabilizer-compatible mechanical provisions at least for:
- Backspace 2U
- Enter 2.25U
- Left Shift 2.25U
- Right Shift 2.75U
- Spacebar 6.25U

Implementation note:
- Use Cherry-style stabilizer cutout/hole geometry from validated KiCad library footprints.
- Keep switch + stabilizer footprints mechanically tied to same key center references from KLE/GH60 template.

## 6) PCB layout plan (2-layer)

## Board mechanics
- Outline: 285.75 mm × 95.25 mm (GH60 target)
- Mounting holes: GH60-compatible pattern (use case drawing/template for exact XY lock)
- Keep copper keepout around mounting holes and USB connector shell tabs as required

## Layer strategy
- Top layer: majority of matrix columns and USB routing near connector
- Bottom layer: matrix rows and remaining interconnects
- Bottom copper pour: solid GND plane preferred
- Stitch GND vias around USB section and board edges

## Routing and spacing targets (starter)
- Matrix traces: 6/6 mil minimum (or your fab default)
- USB D+/D-:
  - Route as short differential pair from connector to RP2040 USB pins
  - Length match and impedance control to board stack-up capability
  - Avoid stubs and excessive vias
- Power traces:
  - VBUS and 3.3V wider than matrix traces (e.g., >= 15 mil where practical)

## Placement guidance
- USB-C connector centered or case-aligned at top edge
- RP2040 + crystal + flash tightly grouped near USB region
- Decoupling capacitors immediately adjacent to RP2040 power pins
- Matrix diodes placed consistently to simplify assembly and inspection
- Reset/Boot buttons accessible from board edge or through case openings

## 7) Hot-swap socket clearance review (requested)

Requested check: hot-swap sockets versus through-hole diode bodies and case mounting points.

Design conclusion:
1. Hot-swap socket vs through-hole diode conflict risk: HIGH if DO-35 diodes are placed on same side as sockets in dense 60% rows.
2. Recommended resolution:
   - Use SMD matrix diodes (SOD-123 or SOD-323) on opposite side of sockets, OR
   - Keep through-hole diodes only if they are offset away from socket keepout and verified in 3D viewer.
3. Case standoff interference risk:
   - Near GH60 mounting holes, socket pads and diode footprints can violate standoff keepouts.
   - Reserve circular keepouts around each mounting hole before final routing.

Unverified until KiCad 3D + DRC check:
- Exact clearance of chosen Kailh socket footprint against chosen diode footprint at every key position
- Clearance from socket pads/traces to mounting hole keepouts for your exact GH60 case

## 8) ERC/DRC checklist and unresolved issues

Electrical checks to pass in KiCad ERC:
- No unpowered RP2040/flash pins
- USB CC resistors present and tied correctly to GND
- VBUS protection chain present (TVS + fuse)
- All matrix diodes polarised consistently (COL->ROW)
- BOOT and RESET buttons connected correctly

PCB checks to pass in KiCad DRC:
- No trace-to-pad clearance violations under hot-swap sockets
- No diode/socket overlap in courtyard or 3D models
- USB differential pair constraints met
- Copper-to-edge and hole annular ring rules met
- Mounting hole keepouts respected

Current unresolved items (must be closed before fabrication):
1. Final mechanical validation of GH60 mounting coordinates for your specific case vendor
2. Final hot-swap socket + diode footprint coexistence validation across all 61 keys
3. USB D+/D- impedance verification against chosen PCB stack-up from fab
4. Optional ESD/shield grounding strategy selection (direct GND vs RC/ferrite)

## 9) Preliminary BOM (core electronics)

Reference choices (can be substituted):
- U1: RP2040 QFN-56
- U2: QSPI NOR Flash 3.3V (W25Q128JV or equivalent)
- Y1: 12 MHz crystal, footprint per selected part
- U3: 3.3V LDO regulator (AP2112K-3.3 or equivalent)
- J1: USB Type-C receptacle (USB2.0 device-compatible footprint)
- F1: Polyfuse 500 mA hold (resettable)
- D_ESD1: USB data ESD array (low capacitance)
- D_TVS1: 5V TVS on VBUS
- R_CC1, R_CC2: 5.1k 1%
- R_USBP, R_USBN: 22R (optional/placement-dependent)
- R_RUN: 100k pull-up
- C_decoupling: multiple 100 nF + bulk caps per sections above
- SW_BOOT: momentary pushbutton
- SW_RESET: momentary pushbutton
- SW1..SW61: MX-compatible switches (with Kailh hot-swap sockets HS1..HS61)
- D1..D61: matrix diodes (recommend SMD for clearance)
- STAB footprints: per large key positions
- Mounting hardware: GH60 hole-compatible NPTH/PTH as case requires

## 10) Labeling conventions (silkscreen)

- Board title: `Merritt Custom Keyboard`
- Revision field: `REV A` (update per release)
- Label each row/column net near RP2040 breakout (`ROW0..ROW4`, `COL0..COL13`)
- Label USB section: `VBUS`, `CC1`, `CC2`, `D+`, `D-`, `ESD`
- Label buttons: `RESET`, `BOOT`
- Add polarity marks on all diodes and TVS

## 11) Deliverables in this project

- Hardware specification: `docs/merritt-custom-keyboard-spec.md` (this file)
- Firmware scaffold and keymap under `firmware/qmk/...`
- Build, flash, and test instructions included in firmware README

