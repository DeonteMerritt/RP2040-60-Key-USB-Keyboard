{
  "version": 1,
  "symbols": [
    {
      "id": "esp32_1",
      "type": "reg:esp32-devkit-v1",
      "ref": "U1",
      "x": 50,
      "y": 147,
      "rotation": 0,
      "mirror": false
    },
    {
      "id": "btn_00",
      "type": "reg:push-button",
      "ref": "U2",
      "x": 92,
      "y": 43,
      "rotation": 0,
      "mirror": false
    },
    {
      "id": "btn_01",
      "type": "reg:push-button",
      "ref": "U3",
      "x": 92,
      "y": 198,
      "rotation": 0,
      "mirror": false
    },
    {
      "id": "btn_02",
      "type": "reg:push-button",
      "ref": "U4",
      "x": 92,
      "y": 150,
      "rotation": 0,
      "mirror": false
    },
    {
      "id": "btn_10",
      "type": "reg:push-button",
      "ref": "U5",
      "x": 92,
      "y": 69,
      "rotation": 0,
      "mirror": false
    },
    {
      "id": "btn_11",
      "type": "reg:push-button",
      "ref": "U6",
      "x": 92,
      "y": 114,
      "rotation": 0,
      "mirror": false
    },
    {
      "id": "btn_12",
      "type": "reg:push-button",
      "ref": "U7",
      "x": 92,
      "y": 169,
      "rotation": 0,
      "mirror": false
    },
    {
      "id": "btn_20",
      "type": "reg:push-button",
      "ref": "U8",
      "x": 92,
      "y": 17,
      "rotation": 0,
      "mirror": false
    },
    {
      "id": "btn_21",
      "type": "reg:push-button",
      "ref": "U9",
      "x": 92,
      "y": 224,
      "rotation": 0,
      "mirror": false
    },
    {
      "id": "btn_22",
      "type": "reg:push-button",
      "ref": "U10",
      "x": 92,
      "y": 132,
      "rotation": 0,
      "mirror": false
    },
    {
      "id": "d_00",
      "type": "diode",
      "ref": "D1",
      "x": 126,
      "y": 50,
      "rotation": 0,
      "mirror": false
    },
    {
      "id": "d_01",
      "type": "diode",
      "ref": "D2",
      "x": 126,
      "y": 205,
      "rotation": 0,
      "mirror": false
    },
    {
      "id": "d_02",
      "type": "diode",
      "ref": "D3",
      "x": 126,
      "y": 157,
      "rotation": 0,
      "mirror": false
    },
    {
      "id": "d_10",
      "type": "diode",
      "ref": "D4",
      "x": 126,
      "y": 76,
      "rotation": 0,
      "mirror": false
    },
    {
      "id": "d_11",
      "type": "diode",
      "ref": "D5",
      "x": 126,
      "y": 121,
      "rotation": 0,
      "mirror": false
    },
    {
      "id": "d_12",
      "type": "diode",
      "ref": "D6",
      "x": 126,
      "y": 176,
      "rotation": 0,
      "mirror": false
    },
    {
      "id": "d_20",
      "type": "diode",
      "ref": "D7",
      "x": 126,
      "y": 24,
      "rotation": 0,
      "mirror": false
    },
    {
      "id": "d_21",
      "type": "diode",
      "ref": "D8",
      "x": 126,
      "y": 231,
      "rotation": 0,
      "mirror": false
    },
    {
      "id": "d_22",
      "type": "diode",
      "ref": "D9",
      "x": 126,
      "y": 95,
      "rotation": 0,
      "mirror": false
    }
  ],
  "wires": [
    {
      "id": "bbs_w_0",
      "points": [
        {
          "x": 56,
          "y": 135
        },
        {
          "x": 66,
          "y": 135
        },
        {
          "x": 66,
          "y": 119
        },
        {
          "x": 34,
          "y": 119
        },
        {
          "x": 34,
          "y": 135
        },
        {
          "x": 44,
          "y": 135
        }
      ],
      "net": "0"
    },
    {
      "id": "bbs_w_1",
      "points": [
        {
          "x": 44,
          "y": 141
        },
        {
          "x": 21,
          "y": 141
        },
        {
          "x": 21,
          "y": 42
        },
        {
          "x": 86,
          "y": 42
        }
      ],
      "net": "N_IO14"
    },
    {
      "id": "bbs_w_2",
      "points": [
        {
          "x": 44,
          "y": 141
        },
        {
          "x": 21,
          "y": 141
        },
        {
          "x": 21,
          "y": 68
        },
        {
          "x": 86,
          "y": 68
        }
      ],
      "net": "N_IO14"
    },
    {
      "id": "bbs_w_3",
      "points": [
        {
          "x": 44,
          "y": 141
        },
        {
          "x": 21,
          "y": 141
        },
        {
          "x": 21,
          "y": 16
        },
        {
          "x": 86,
          "y": 16
        }
      ],
      "net": "N_IO14"
    },
    {
      "id": "bbs_w_4",
      "points": [
        {
          "x": 44,
          "y": 143
        },
        {
          "x": 18,
          "y": 143
        },
        {
          "x": 18,
          "y": 197
        },
        {
          "x": 86,
          "y": 197
        }
      ],
      "net": "N_IO27"
    },
    {
      "id": "bbs_w_5",
      "points": [
        {
          "x": 44,
          "y": 143
        },
        {
          "x": 18,
          "y": 143
        },
        {
          "x": 18,
          "y": 113
        },
        {
          "x": 86,
          "y": 113
        }
      ],
      "net": "N_IO27"
    },
    {
      "id": "bbs_w_6",
      "points": [
        {
          "x": 44,
          "y": 143
        },
        {
          "x": 18,
          "y": 143
        },
        {
          "x": 18,
          "y": 223
        },
        {
          "x": 86,
          "y": 223
        }
      ],
      "net": "N_IO27"
    },
    {
      "id": "bbs_w_7",
      "points": [
        {
          "x": 44,
          "y": 147
        },
        {
          "x": 12,
          "y": 147
        },
        {
          "x": 12,
          "y": 32
        },
        {
          "x": 126,
          "y": 32
        },
        {
          "x": 126,
          "y": 27
        }
      ],
      "net": "N_IO25"
    },
    {
      "id": "bbs_w_8",
      "points": [
        {
          "x": 44,
          "y": 147
        },
        {
          "x": 12,
          "y": 147
        },
        {
          "x": 12,
          "y": 239
        },
        {
          "x": 126,
          "y": 239
        },
        {
          "x": 126,
          "y": 234
        }
      ],
      "net": "N_IO25"
    },
    {
      "id": "bbs_w_9",
      "points": [
        {
          "x": 44,
          "y": 147
        },
        {
          "x": 12,
          "y": 147
        },
        {
          "x": 12,
          "y": 103
        },
        {
          "x": 126,
          "y": 103
        },
        {
          "x": 126,
          "y": 98
        }
      ],
      "net": "N_IO25"
    },
    {
      "id": "bbs_w_10",
      "points": [
        {
          "x": 44,
          "y": 149
        },
        {
          "x": 24,
          "y": 149
        },
        {
          "x": 24,
          "y": 84
        },
        {
          "x": 126,
          "y": 84
        },
        {
          "x": 126,
          "y": 79
        }
      ],
      "net": "N_IO33"
    },
    {
      "id": "bbs_w_11",
      "points": [
        {
          "x": 44,
          "y": 149
        },
        {
          "x": 24,
          "y": 149
        },
        {
          "x": 24,
          "y": 179
        },
        {
          "x": 111,
          "y": 179
        },
        {
          "x": 111,
          "y": 129
        },
        {
          "x": 126,
          "y": 129
        },
        {
          "x": 126,
          "y": 124
        }
      ],
      "net": "N_IO33"
    },
    {
      "id": "bbs_w_12",
      "points": [
        {
          "x": 44,
          "y": 149
        },
        {
          "x": 24,
          "y": 149
        },
        {
          "x": 24,
          "y": 187
        },
        {
          "x": 126,
          "y": 187
        },
        {
          "x": 126,
          "y": 179
        }
      ],
      "net": "N_IO33"
    },
    {
      "id": "bbs_w_13",
      "points": [
        {
          "x": 44,
          "y": 151
        },
        {
          "x": 15,
          "y": 151
        },
        {
          "x": 15,
          "y": 58
        },
        {
          "x": 126,
          "y": 58
        },
        {
          "x": 126,
          "y": 53
        }
      ],
      "net": "N_IO32"
    },
    {
      "id": "bbs_w_14",
      "points": [
        {
          "x": 44,
          "y": 151
        },
        {
          "x": 15,
          "y": 151
        },
        {
          "x": 15,
          "y": 213
        },
        {
          "x": 126,
          "y": 213
        },
        {
          "x": 126,
          "y": 208
        }
      ],
      "net": "N_IO32"
    },
    {
      "id": "bbs_w_15",
      "points": [
        {
          "x": 44,
          "y": 151
        },
        {
          "x": 15,
          "y": 151
        },
        {
          "x": 15,
          "y": 183
        },
        {
          "x": 114,
          "y": 183
        },
        {
          "x": 114,
          "y": 165
        },
        {
          "x": 126,
          "y": 165
        },
        {
          "x": 126,
          "y": 160
        }
      ],
      "net": "N_IO32"
    },
    {
      "id": "bbs_w_16",
      "points": [
        {
          "x": 56,
          "y": 149
        },
        {
          "x": 86,
          "y": 149
        }
      ],
      "net": "N_IO18"
    },
    {
      "id": "bbs_w_17",
      "points": [
        {
          "x": 56,
          "y": 149
        },
        {
          "x": 76,
          "y": 149
        },
        {
          "x": 76,
          "y": 168
        },
        {
          "x": 86,
          "y": 168
        }
      ],
      "net": "N_IO18"
    },
    {
      "id": "bbs_w_18",
      "points": [
        {
          "x": 56,
          "y": 149
        },
        {
          "x": 76,
          "y": 149
        },
        {
          "x": 76,
          "y": 131
        },
        {
          "x": 86,
          "y": 131
        }
      ],
      "net": "N_IO18"
    },
    {
      "id": "bbs_w_19",
      "points": [
        {
          "x": 98,
          "y": 42
        },
        {
          "x": 126,
          "y": 42
        },
        {
          "x": 126,
          "y": 47
        }
      ],
      "net": "N8"
    },
    {
      "id": "bbs_w_20",
      "points": [
        {
          "x": 98,
          "y": 197
        },
        {
          "x": 126,
          "y": 197
        },
        {
          "x": 126,
          "y": 202
        }
      ],
      "net": "N11"
    },
    {
      "id": "bbs_w_21",
      "points": [
        {
          "x": 98,
          "y": 149
        },
        {
          "x": 126,
          "y": 149
        },
        {
          "x": 126,
          "y": 154
        }
      ],
      "net": "N14"
    },
    {
      "id": "bbs_w_22",
      "points": [
        {
          "x": 98,
          "y": 68
        },
        {
          "x": 126,
          "y": 68
        },
        {
          "x": 126,
          "y": 73
        }
      ],
      "net": "N17"
    },
    {
      "id": "bbs_w_23",
      "points": [
        {
          "x": 98,
          "y": 113
        },
        {
          "x": 126,
          "y": 113
        },
        {
          "x": 126,
          "y": 118
        }
      ],
      "net": "N20"
    },
    {
      "id": "bbs_w_24",
      "points": [
        {
          "x": 98,
          "y": 168
        },
        {
          "x": 126,
          "y": 168
        },
        {
          "x": 126,
          "y": 173
        }
      ],
      "net": "N23"
    },
    {
      "id": "bbs_w_25",
      "points": [
        {
          "x": 98,
          "y": 16
        },
        {
          "x": 126,
          "y": 16
        },
        {
          "x": 126,
          "y": 21
        }
      ],
      "net": "N26"
    },
    {
      "id": "bbs_w_26",
      "points": [
        {
          "x": 98,
          "y": 223
        },
        {
          "x": 126,
          "y": 223
        },
        {
          "x": 126,
          "y": 228
        }
      ],
      "net": "N29"
    },
    {
      "id": "bbs_w_27",
      "points": [
        {
          "x": 98,
          "y": 131
        },
        {
          "x": 108,
          "y": 131
        },
        {
          "x": 108,
          "y": 87
        },
        {
          "x": 126,
          "y": 87
        },
        {
          "x": 126,
          "y": 92
        }
      ],
      "net": "N32"
    }
  ],
  "junctions": [
    {
      "id": "j_44_141",
      "x": 44,
      "y": 141
    },
    {
      "id": "j_21_141",
      "x": 21,
      "y": 141
    },
    {
      "id": "j_21_42",
      "x": 21,
      "y": 42
    },
    {
      "id": "j_21_68",
      "x": 21,
      "y": 68
    },
    {
      "id": "j_44_143",
      "x": 44,
      "y": 143
    },
    {
      "id": "j_18_143",
      "x": 18,
      "y": 143
    },
    {
      "id": "j_18_197",
      "x": 18,
      "y": 197
    },
    {
      "id": "j_44_147",
      "x": 44,
      "y": 147
    },
    {
      "id": "j_12_147",
      "x": 12,
      "y": 147
    },
    {
      "id": "j_12_103",
      "x": 12,
      "y": 103
    },
    {
      "id": "j_44_149",
      "x": 44,
      "y": 149
    },
    {
      "id": "j_24_149",
      "x": 24,
      "y": 149
    },
    {
      "id": "j_24_179",
      "x": 24,
      "y": 179
    },
    {
      "id": "j_44_151",
      "x": 44,
      "y": 151
    },
    {
      "id": "j_15_151",
      "x": 15,
      "y": 151
    },
    {
      "id": "j_15_183",
      "x": 15,
      "y": 183
    },
    {
      "id": "j_56_149",
      "x": 56,
      "y": 149
    },
    {
      "id": "j_76_149",
      "x": 76,
      "y": 149
    }
  ],
  "netLabels": [
    {
      "id": "bbs_nl_0",
      "name": "GND",
      "x": 56,
      "y": 135,
      "owner": "esp32_1",
      "anchor": "start"
    },
    {
      "id": "bbs_nl_1",
      "name": "N_IO14",
      "x": 44,
      "y": 141,
      "owner": "esp32_1",
      "anchor": "end"
    },
    {
      "id": "bbs_nl_2",
      "name": "N_IO27",
      "x": 44,
      "y": 143,
      "owner": "esp32_1",
      "anchor": "end"
    },
    {
      "id": "bbs_nl_3",
      "name": "N_IO25",
      "x": 44,
      "y": 147,
      "owner": "esp32_1",
      "anchor": "end"
    },
    {
      "id": "bbs_nl_4",
      "name": "N_IO33",
      "x": 44,
      "y": 149,
      "owner": "esp32_1",
      "anchor": "end"
    },
    {
      "id": "bbs_nl_5",
      "name": "N_IO32",
      "x": 44,
      "y": 151,
      "owner": "esp32_1",
      "anchor": "end"
    },
    {
      "id": "bbs_nl_6",
      "name": "N_IO18",
      "x": 56,
      "y": 149,
      "owner": "esp32_1",
      "anchor": "start"
    },
    {
      "id": "bbs_nl_7",
      "name": "N8",
      "x": 98,
      "y": 42,
      "owner": "btn_00",
      "anchor": "start"
    },
    {
      "id": "bbs_nl_8",
      "name": "N11",
      "x": 98,
      "y": 197,
      "owner": "btn_01",
      "anchor": "start"
    },
    {
      "id": "bbs_nl_9",
      "name": "N14",
      "x": 98,
      "y": 149,
      "owner": "btn_02",
      "anchor": "start"
    },
    {
      "id": "bbs_nl_10",
      "name": "N17",
      "x": 98,
      "y": 68,
      "owner": "btn_10",
      "anchor": "start"
    },
    {
      "id": "bbs_nl_11",
      "name": "N20",
      "x": 98,
      "y": 113,
      "owner": "btn_11",
      "anchor": "start"
    },
    {
      "id": "bbs_nl_12",
      "name": "N23",
      "x": 98,
      "y": 168,
      "owner": "btn_12",
      "anchor": "start"
    },
    {
      "id": "bbs_nl_13",
      "name": "N26",
      "x": 98,
      "y": 16,
      "owner": "btn_20",
      "anchor": "start"
    },
    {
      "id": "bbs_nl_14",
      "name": "N29",
      "x": 98,
      "y": 223,
      "owner": "btn_21",
      "anchor": "start"
    },
    {
      "id": "bbs_nl_15",
      "name": "N32",
      "x": 98,
      "y": 131,
      "owner": "btn_22",
      "anchor": "start"
    }
  ],
  "probes": [],
  "directives": [],
  "breadboardSync": {
    "sourceHash": "32738:723077181",
    "symbolIds": [
      "esp32_1",
      "btn_00",
      "btn_01",
      "btn_02",
      "btn_10",
      "btn_11",
      "btn_12",
      "btn_20",
      "btn_21",
      "btn_22",
      "d_00",
      "d_01",
      "d_02",
      "d_10",
      "d_11",
      "d_12",
      "d_20",
      "d_21",
      "d_22"
    ],
    "wireIds": [
      "bbs_w_0",
      "bbs_w_1",
      "bbs_w_2",
      "bbs_w_3",
      "bbs_w_4",
      "bbs_w_5",
      "bbs_w_6",
      "bbs_w_7",
      "bbs_w_8",
      "bbs_w_9",
      "bbs_w_10",
      "bbs_w_11",
      "bbs_w_12",
      "bbs_w_13",
      "bbs_w_14",
      "bbs_w_15",
      "bbs_w_16",
      "bbs_w_17",
      "bbs_w_18",
      "bbs_w_19",
      "bbs_w_20",
      "bbs_w_21",
      "bbs_w_22",
      "bbs_w_23",
      "bbs_w_24",
      "bbs_w_25",
      "bbs_w_26",
      "bbs_w_27"
    ],
    "netLabelIds": [
      "bbs_nl_0",
      "bbs_nl_1",
      "bbs_nl_2",
      "bbs_nl_3",
      "bbs_nl_4",
      "bbs_nl_5",
      "bbs_nl_6",
      "bbs_nl_7",
      "bbs_nl_8",
      "bbs_nl_9",
      "bbs_nl_10",
      "bbs_nl_11",
      "bbs_nl_12",
      "bbs_nl_13",
      "bbs_nl_14",
      "bbs_nl_15"
    ]
  }
}