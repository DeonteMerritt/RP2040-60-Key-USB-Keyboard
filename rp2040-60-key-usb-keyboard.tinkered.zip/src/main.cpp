#include <Arduino.h>
#include "config.h"

static bool keyState[ROWS][COLS] = {false};
static uint32_t lastScanMs = 0;
static uint32_t lastGridPrintMs = 0;

static void setAllRowsHiZ() {
  for (uint8_t r = 0; r < ROWS; r++) {
    pinMode(ROW_PINS[r], INPUT);
  }
}

static void scanMatrix(bool outState[ROWS][COLS]) {
  // Default all keys to not pressed before scan
  for (uint8_t r = 0; r < ROWS; r++) {
    for (uint8_t c = 0; c < COLS; c++) {
      outState[r][c] = false;
    }
  }

  for (uint8_t r = 0; r < ROWS; r++) {
    // Inactive rows float (Hi-Z), active row drives LOW
    setAllRowsHiZ();
    pinMode(ROW_PINS[r], OUTPUT);
    digitalWrite(ROW_PINS[r], LOW);

    // Small settle time for GPIO matrix
    delayMicroseconds(3);

    for (uint8_t c = 0; c < COLS; c++) {
      // Columns use INPUT_PULLUP, so LOW means key pressed on active row
      outState[r][c] = (digitalRead(COL_PINS[c]) == LOW);
    }
  }

  // Leave rows inactive after scan
  setAllRowsHiZ();
}

static void printKeyEvent(uint8_t row, uint8_t col, bool pressed) {
  Serial.printf("K%u%u %s\n", row, col, pressed ? "PRESSED" : "RELEASED");
}

static void printGrid(const bool state[ROWS][COLS]) {
  Serial.println("3x3 key-state:");
  for (uint8_t r = 0; r < ROWS; r++) {
    Serial.printf("[%c %c %c]\n",
                  state[r][0] ? '1' : '0',
                  state[r][1] ? '1' : '0',
                  state[r][2] ? '1' : '0');
  }
  Serial.println();
}

void setup() {
  Serial.begin(SERIAL_BAUD);

  // Columns are read inputs with pull-ups
  for (uint8_t c = 0; c < COLS; c++) {
    pinMode(COL_PINS[c], INPUT_PULLUP);
  }

  // Rows idle as high impedance inputs
  setAllRowsHiZ();

  // Initial matrix snapshot
  scanMatrix(keyState);

  Serial.println("ESP32 3x3 matrix scanner started");
}

void loop() {
  const uint32_t now = millis();

  if (now - lastScanMs >= SCAN_INTERVAL_MS) {
    lastScanMs = now;

    bool newState[ROWS][COLS];
    scanMatrix(newState);

    // Edge detection: print only changes
    for (uint8_t r = 0; r < ROWS; r++) {
      for (uint8_t c = 0; c < COLS; c++) {
        if (newState[r][c] != keyState[r][c]) {
          keyState[r][c] = newState[r][c];
          printKeyEvent(r, c, keyState[r][c]);
        }
      }
    }
  }

  if (now - lastGridPrintMs >= GRID_PRINT_INTERVAL_MS) {
    lastGridPrintMs = now;
    printGrid(keyState);
  }
}
