#pragma once

#include <Arduino.h>

static constexpr uint32_t SERIAL_BAUD = 115200;

static constexpr uint8_t ROWS = 3;
static constexpr uint8_t COLS = 3;

// From wiring/pin-map (use exact GPIO numbers in code)
static constexpr uint8_t ROW_PINS[ROWS] = {32, 33, 25};
static constexpr uint8_t COL_PINS[COLS] = {14, 27, 18};

// Timing (non-blocking)
static constexpr uint32_t SCAN_INTERVAL_MS = 5;
static constexpr uint32_t GRID_PRINT_INTERVAL_MS = 250;
